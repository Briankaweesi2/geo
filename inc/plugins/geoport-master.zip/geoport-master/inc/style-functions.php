<?php
/**
* Define geoport class
*/
class Geoport_Master_Core {

	/* =================================================================
    = Menu 1 color
    ====================================================================*/
	public function Menu1_Style() {

  		if(function_exists( 'geoport_framework_init' ) ) {
  			/* =================================================================
		    = Menu 1 color
		    ====================================================================*/
		    $menu1_bg_color = geoport_get_option( 'menu1_bg_color' );
		    if (!empty($menu1_bg_color)) {
		      $menu1_bg_color = $menu1_bg_color;
		    } else {
		      $menu1_bg_color = 'transparent';
		    }
		    $menu1_font_color = geoport_get_option( 'menu1_font_color' );
		    if (!empty($menu1_font_color)) {
		      $menu1_font_color = $menu1_font_color;
		    } else {
		      $menu1_font_color = '#ffffff';
		    }
		    $menu1_hover_font_color = geoport_get_option( 'menu1_hover_font_color' );
		    if (!empty($menu1_hover_font_color)) {
		      $menu1_hover_font_color = $menu1_hover_font_color;
		    } else {
		      $menu1_hover_font_color = '#39bdb2';
		    }
		    // Submenu
		    $submenu1_bg_color = geoport_get_option( 'submenu1_bg_color' );
		    if (!empty($submenu1_bg_color)) {
		      $submenu1_bg_color = $submenu1_bg_color;
		    } else {
		      $submenu1_bg_color = '#ffffff';
		    }
		    $submenu1_color = geoport_get_option( 'submenu1_color' );
		    if (!empty($submenu1_color)) {
		      $submenu1_color = $submenu1_color;
		    } else {
		      $submenu1_color = '#000d38';
		    }
		    $submenu1_hover_color = geoport_get_option( 'submenu1_hover_color' );
		    if (!empty($submenu1_hover_color)) {
		      $submenu1_hover_color = $submenu1_hover_color;
		    } else {
		      $submenu1_hover_color = '#39bdb2';
		    }
		    $submenu1_border_color = geoport_get_option( 'submenu1_border_color' );
		    if (!empty($submenu1_border_color)) {
		      $submenu1_border_color = $submenu1_border_color;
		    } else {
		      $submenu1_border_color = '#eceef0';
		    }

		    // Button
		    $menu1_btn_font_color = geoport_get_option( 'menu1_btn_font_color' );
		    if (!empty($menu1_btn_font_color)) {
		      $menu1_btn_font_color = $menu1_btn_font_color;
		    } else {
		      $menu1_btn_font_color = '#ffffff';
		    }
		    $menu1_btn_bg_color = geoport_get_option( 'menu1_btn_bg_color' );
		    if (!empty($menu1_btn_bg_color)) {
		      $menu1_btn_bg_color = $menu1_btn_bg_color;
		    } else {
		      $menu1_btn_bg_color = 'transparent';
		    } 
		    $menu1_btn_border_color = geoport_get_option( 'menu1_btn_border_color' );
		    if (!empty($menu1_btn_border_color)) {
		      $menu1_btn_border_color = $menu1_btn_border_color;
		    } else {
		      $menu1_btn_border_color = 'rgba(255, 255, 255, 0.3)';
		    }

		    $menu1_btn_hf_color = geoport_get_option( 'menu1_btn_hf_color' );
		    if (!empty($menu1_btn_hf_color)) {
		      $menu1_btn_hf_color = $menu1_btn_hf_color;
		    } else {
		      $menu1_btn_hf_color = '#ffffff';
		    }
		    $menu1_btn_hb_color = geoport_get_option( 'menu1_btn_hb_color' );
		    if (!empty($menu1_btn_hb_color)) {
		      $menu1_btn_hb_color = $menu1_btn_hb_color;
		    } else {
		      $menu1_btn_hb_color = '#ff5e14';
		    }

			// Sticky Menu
			$sticky_menu1_bg_color = geoport_get_option( 'sticky_menu1_bg_color' );
		    if (!empty($sticky_menu1_bg_color)) {
		      $sticky_menu1_bg_color = $sticky_menu1_bg_color;
		    } else {
		      $sticky_menu1_bg_color = '#ffffff';
		    }
		    $sticky_menu1_font_color = geoport_get_option( 'sticky_menu1_font_color' );
		    if (!empty($sticky_menu1_font_color)) {
		      $sticky_menu1_font_color = $sticky_menu1_font_color;
		    } else {
		      $sticky_menu1_font_color = '#568ea5';
		    }
		    $sticky_menu1_hover_font_color = geoport_get_option( 'sticky_menu1_hover_font_color' );
		    if (!empty($sticky_menu1_hover_font_color)) {
		      $sticky_menu1_hover_font_color = $sticky_menu1_hover_font_color;
		    } else {
		      $sticky_menu1_hover_font_color = '#ff5e14';
		    }
		    
		    echo "<style>
				/* = Menu 1 Color = */
			    .transparent-header.default-header {
			        background: $menu1_bg_color;
			    }
				.transparent-header.default-header ul li a {
					color: $menu1_font_color;
				}
				.transparent-header.default-header .main-menu ul li.menu-item-has-children.current_page_ancestor > a::before,
				.transparent-header.default-header .main-menu ul li.menu-item-has-children.active > a::before,
				.transparent-header.default-header .main-menu ul li.menu-item-has-children:hover > a::before,
				.transparent-header.default-header .main-menu ul li > .submenu li.current-menu-item>a,
				.transparent-header.default-header .main-menu ul li.current-menu-ancestor>a::before,
				.transparent-header.default-header .main-menu ul li.current-menu-ancestor>a,
				.transparent-header.default-header .main-menu ul li.current-menu-item>a,
				.transparent-header.default-header .main-menu ul li:hover > a, 
				.transparent-header.default-header .main-menu ul li.active>a,
				.transparent-header.default-header .main-menu ul li:hover>a {
					color: $menu1_hover_font_color;
				}

				/* = Sub Menu 1 Color = */
				.transparent-header.default-header .main-menu ul li > .submenu {
					background-color: $submenu1_bg_color;
				}
				.transparent-header.default-header .main-menu ul li > .submenu li a {
					color: $submenu1_color;
				}
				.transparent-header.default-header .main-menu ul li .submenu > li:hover > a {
					color: $submenu1_hover_color;
				}
				.transparent-header.default-header .main-menu ul li > .submenu li {
					border-color: $submenu1_border_color;
				}

				/* = Menu 1 Button Color = */
				.transparent-header.default-header .btn.transparent-btn {
					color: $menu1_btn_font_color;
					background: $menu1_btn_bg_color;
				}
				.transparent-header.default-header .btn.transparent-btn {
					border-color: $menu1_btn_border_color;
				}
				.transparent-header.default-header .btn.transparent-btn:hover {
					color: $menu1_btn_hf_color;
					background: $menu1_btn_hb_color;
					border-color: $menu1_btn_hb_color;
				}
				
				/* = Sticky Menu 1 Color = */
				.transparent-header.default-header.sticky-header {
					background: $sticky_menu1_bg_color;
				}
				.transparent-header.default-header.sticky-header .main-menu ul li a {
					color: $sticky_menu1_font_color;
				}
				.transparent-header.default-header.sticky-header .main-menu ul li.current-menu-ancestor>a,
				.transparent-header.default-header.sticky-header .main-menu ul li.current-menu-item>a,
				.transparent-header.default-header.sticky-header .main-menu ul li.active>a,
				.transparent-header.default-header.sticky-header .main-menu ul li a:hover {
					color: $sticky_menu1_hover_font_color;
				}
				
				/* = Sticky Menu 1 Button Color = */
				.transparent-header.default-header.sticky-header .transparent-btn {
					color: $sticky_menu1_font_color;
				}
		    </style>";
		}
	}



	/* =================================================================
    = Menu 2 color
    ====================================================================*/
	public function Menu2_Style() {

  		if(function_exists( 'geoport_framework_init' ) ) {

		    /* =================================================================
		    = Menu 2 color 
		    ====================================================================*/
		    $menu2_bg_color = geoport_get_option( 'menu2_bg_color' );
		    if (!empty( $menu2_bg_color )) {
		      $menu2_bg_color = $menu2_bg_color;
		    } else {
		      $menu2_bg_color = 'transparent';
		    }
		    $menu2_font_color = geoport_get_option( 'menu2_font_color' );
		    if (!empty( $menu2_font_color )) {
		      $menu2_font_color = $menu2_font_color;
		    } else {
		      $menu2_font_color = '#568ea5';
		    }
		    $menu2_hover_font_color = geoport_get_option( 'menu2_hover_font_color' );
		    if (!empty( $menu2_hover_font_color )) {
		      $menu2_hover_font_color = $menu2_hover_font_color;
		    } else {
		      $menu2_hover_font_color = '#ff5e14';
		    }

		    // Submenu 2
		    $submenu2_bg_color = geoport_get_option( 'submenu2_bg_color' );
		    if (!empty( $submenu2_bg_color )) {
		      $submenu2_bg_color = $submenu2_bg_color;
		    } else {
		      $submenu2_bg_color = '#ffffff';
		    }
		    $submenu2_font_color = geoport_get_option( 'submenu2_font_color' );
		    if (!empty( $submenu2_font_color )) {
		      $submenu2_font_color = $submenu2_font_color;
		    } else {
		      $submenu2_font_color = '#568ea5';
		    }
		    $submenu2_hover_color = geoport_get_option( 'submenu2_hover_color' );
		    if (!empty( $submenu2_hover_color )) {
		      $submenu2_hover_color = $submenu2_hover_color;
		    } else {
		      $submenu2_hover_color = '#ff5e14';
		    }
		    $submenu2_border_color = geoport_get_option( 'submenu2_border_color' );
		    if (!empty( $submenu2_border_color )) {
		      $submenu2_border_color = $submenu2_border_color;
		    } else {
		      $submenu2_border_color = '#eceef0';
		    }

		    // Button
		    $menu2_btn_font_color = geoport_get_option( 'menu2_btn_font_color' );
		    if (!empty( $menu2_btn_font_color )) {
		      $menu2_btn_font_color = $menu2_btn_font_color;
		    } else {
		      $menu2_btn_font_color = '#568ea5';
		    }
		    $menu2_btn_bg_color = geoport_get_option( 'menu2_btn_bg_color' );
		    if (!empty( $menu2_btn_bg_color )) {
		      $menu2_btn_bg_color = $menu2_btn_bg_color;
		    } else {
		      $menu2_btn_bg_color = 'transparent';
		    } 
		    $menu2_btn_border_color = geoport_get_option( 'menu2_btn_border_color' );
		    if (!empty( $menu2_btn_border_color )) {
		      $menu2_btn_border_color = $menu2_btn_border_color;
		    } else {
		      $menu2_btn_border_color = '#d7edff';
		    }

		    $menu2_btn_hf_color = geoport_get_option( 'menu2_btn_hf_color' );
		    if (!empty( $menu2_btn_hf_color )) {
		      $menu2_btn_hf_color = $menu2_btn_hf_color;
		    } else {
		      $menu2_btn_hf_color = '#ffffff';
		    }
		    $menu2_btn_hb_color = geoport_get_option( 'menu2_btn_hb_color' );
		    if (!empty( $menu2_btn_hb_color )) {
		      $menu2_btn_hb_color = $menu2_btn_hb_color;
		    } else {
		      $menu2_btn_hb_color = '#ff5e14';
		    }

			// Sticky Menu
			$sticky_menu2_bg_color = geoport_get_option( 'sticky_menu2_bg_color' );
		    if (!empty( $sticky_menu2_bg_color )) {
		      $sticky_menu2_bg_color = $sticky_menu2_bg_color;
		    } else {
		      $sticky_menu2_bg_color = '#ffffff';
		    }
		    $sticky_menu2_font_color = geoport_get_option( 'sticky_menu2_font_color' );
		    if (!empty( $sticky_menu2_font_color )) {
		      $sticky_menu2_font_color = $sticky_menu2_font_color;
		    } else {
		      $sticky_menu2_font_color = '#568ea5';
		    }
		    $sticky_menu2_hover_font_color = geoport_get_option( 'sticky_menu2_hover_font_color' );
		    if (!empty( $sticky_menu2_hover_font_color )) {
		      $sticky_menu2_hover_font_color = $sticky_menu2_hover_font_color;
		    } else {
		      $sticky_menu2_hover_font_color = '#ff5e14';
		    }

		    echo "<style>
				/* = Menu 2 Color = */
			    .transparent-header.header-style-two {
			        background: $menu2_bg_color;
			    }
				.transparent-header.header-style-two ul li a {
					color: $menu2_font_color;
				}
				.transparent-header.header-style-two .main-menu ul li.menu-item-has-children.current_page_ancestor > a::before,
				.transparent-header.header-style-two .main-menu ul li.menu-item-has-children.active > a::before,
				.transparent-header.header-style-two .main-menu ul li.menu-item-has-children:hover > a::before,
				.transparent-header.header-style-two .main-menu ul li > .submenu li.current-menu-item>a,
				.transparent-header.header-style-two .main-menu ul li.current-menu-ancestor>a::before,
				.transparent-header.header-style-two .main-menu ul li.current-menu-ancestor>a,
				.transparent-header.header-style-two .main-menu ul li.current-menu-item>a,
				.transparent-header.header-style-two .main-menu ul li.active>a,
				.transparent-header.header-style-two .main-menu ul li:hover>a,
				.transparent-header.header-style-two .main-menu ul li:hover > a {
					color: $menu2_hover_font_color;
				}


				/* = Sub Menu 2 Color = */
				.transparent-header.header-style-two .main-menu ul li > .submenu {
					background-color: $submenu2_bg_color;
				}
				.transparent-header.header-style-two .main-menu ul li > .submenu li a {
					color: $submenu2_font_color;
				}
				.transparent-header.header-style-two .main-menu ul li .submenu > li:hover > a {
					color: $submenu2_hover_color;
				}
				.transparent-header.header-style-two .main-menu ul li > .submenu li {
					border-color: $submenu2_border_color;
				}

				/* = Menu 2 Button Color = */
				.transparent-header.header-style-two .btn.transparent-btn {
					color: $menu2_btn_font_color;
					background: $menu2_btn_bg_color;
				}
				.transparent-header.header-style-two .btn.transparent-btn {
					border-color: $menu2_btn_border_color;
				}
				.transparent-header.header-style-two .btn.transparent-btn:hover {
					color: $menu2_btn_hf_color;
					background: $menu2_btn_hb_color;
					border-color: $menu2_btn_hb_color;
				}
				
				/* = Sticky Menu 2 Color = */
				.transparent-header.header-style-two.sticky-header {
					background: $sticky_menu2_bg_color;
				}
				.transparent-header.header-style-two.sticky-header .main-menu ul li a {
					color: $sticky_menu2_font_color;
				}
				.transparent-header.header-style-two.sticky-header .main-menu ul li.current-menu-ancestor>a,
				.transparent-header.header-style-two.sticky-header .main-menu ul li.current-menu-item>a,
				.transparent-header.header-style-two.sticky-header .main-menu ul li.active>a,
				.transparent-header.header-style-two.sticky-header .main-menu ul li a:hover {
					color: $sticky_menu2_hover_font_color;
				}
		    </style>";
  		}		
	}



	/* =================================================================
    = Menu 3 color
    ====================================================================*/
	public function Menu3_Style() {

  		if(function_exists( 'geoport_framework_init' ) ) {
  			//Menu
  			$menu3_bg_color = geoport_get_option( 'menu3_bg_color' );
		    if (!empty($menu3_bg_color)) {
		      $menu3_bg_color = $menu3_bg_color;
		    } else {
		      $menu3_bg_color = 'transparent';
		    }
		    $menu3_font_color = geoport_get_option( 'menu3_font_color' );
		    if (!empty($menu3_font_color)) {
		      $menu3_font_color = $menu3_font_color;
		    } else {
		      $menu3_font_color = '#ffffff';
		    }
		    $menu3_hover_font_color = geoport_get_option( 'menu3_hover_font_color' );
		    if (!empty($menu3_hover_font_color)) {
		      $menu3_hover_font_color = $menu3_hover_font_color;
		    } else {
		      $menu3_hover_font_color = '#39bdb2';
		    }

		    // Submenu 3
		    $submenu3_bg_color = geoport_get_option( 'submenu3_bg_color' );
		    if (!empty($submenu3_bg_color)) {
		      $submenu3_bg_color = $submenu3_bg_color;
		    } else {
		      $submenu3_bg_color = '#ffffff';
		    }
		    $submenu3_color = geoport_get_option( 'submenu3_color' );
		    if (!empty($submenu3_color)) {
		      $submenu3_color = $submenu3_color;
		    } else {
		      $submenu3_color = '#000d38';
		    }
		    $submenu3_hover_color = geoport_get_option( 'submenu3_hover_color' );
		    if (!empty($submenu3_hover_color)) {
		      $submenu3_hover_color = $submenu3_hover_color;
		    } else {
		      $submenu3_hover_color = '#ff566e';
		    }
		    $submenu3_border_color = geoport_get_option( 'submenu3_border_color' );
		    if (!empty($submenu3_border_color)) {
		      $submenu3_border_color = $submenu3_border_color;
		    } else {
		      $submenu3_border_color = '#eceef0';
		    }

		    // Button
		    $menu3_btn_color = geoport_get_option( 'menu3_btn_color' );
		    if (!empty($menu3_btn_color)) {
		      $menu3_btn_color = $menu3_btn_color;
		    } else {
		      $menu3_btn_color = '#ffffff';
		    }
		    $menu3_btn_bg_color = geoport_get_option( 'menu3_btn_bg_color' );
		    if (!empty($menu3_btn_bg_color)) {
		      $menu3_btn_bg_color = $menu3_btn_bg_color;
		    } else {
		      $menu3_btn_bg_color = '#34ccff';
		    }  
		    $menu3_btn_border_color = geoport_get_option( 'menu3_btn_border_color' );
		    if (!empty($menu3_btn_border_color)) {
		      $menu3_btn_border_color = $menu3_btn_border_color;
		    } else {
		      $menu3_btn_border_color = '#34ccff';
		    }

		    $menu3_btn_hb_color = geoport_get_option( 'menu3_btn_h_color' );
		    if (!empty($menu3_btn_hb_color)) {
		      $menu3_btn_hb_color = $menu3_btn_hb_color;
		    } else {
		      $menu3_btn_hb_color = '#ffffff';
		    }
		    $menu3_btn_h_f_color = geoport_get_option( 'menu3_btn_h_f_color' );
		    if (!empty($menu3_btn_h_f_color)) {
		      $menu3_btn_h_f_color = $menu3_btn_h_f_color;
		    } else {
		      $menu3_btn_h_f_color = '#ffffff';
		    }

		    echo "<style>

				/* = Menu 3 Color = */
				.s-transparent-header.header3.sticky-menu,
			   .header3 .s-header-container {
			   	background: $menu3_bg_color;
			   }
		      .header3 .s-main-menu ul li > a, 
		      .header3 .s-main-menu ul li.menu-item-has-children > a::before  {
		        	color: $menu3_font_color;
		      }
		      .header3 .main-menu ul li.menu-item-has-children.current_page_ancestor > a::before,
		      .header3 .main-menu ul li.menu-item-has-children.active > a::before,
		      .header3 .main-menu ul li > .submenu li.current-menu-item>a,
		      .header3 .main-menu ul li.current-menu-ancestor>a,
				.header3 .main-menu ul li.current-menu-item>a,
				.header3 .main-menu ul li.current-menu-item>a,
				.header3 .main-menu ul li.active>a,
				.header3 .main-menu ul li:hover>a,
		      .header3 .main-menu ul li:hover > a, 
		      .header3 .main-menu ul li.menu-item-has-children:hover > a::before {
		        	color: $menu3_hover_font_color;
		      }

		      /* = Sub Menu 3 Color = */
				.header3 .main-menu ul li > .submenu {
					background-color: $submenu3_bg_color;
				}
				.header3 .main-menu ul li > .submenu li a {
					color: $submenu3_color;
				}
				.header3 .main-menu ul li .submenu > li:hover > a {
					color: $submenu3_hover_color;
				}
				.header3 .main-menu ul li > .submenu li {
					border-color: $submenu3_border_color;
				}
				
				/* = Menu 3 Button = */
				.header3 a.btn.transparent-btn {
					color: $menu3_btn_color;
					border-color: $menu3_btn_border_color;
					background-color: $menu3_btn_bg_color;
				}	
				.header3 a.btn.transparent-btn:hover {
					box-shadow: 0px 8px 16px 0px $menu3_btn_bg_color;
				}

		    </style>";

		   $menu3_mobile_btn = geoport_get_option( 'menu3_mobile_btn' );
		   
		   if (!empty( $menu3_mobile_btn )) {
			   echo "<style>
					/* = Menu 1 Color = */
					@media screen and ( max-width: 991px ) {
						.header-btn {
						    display: block;
						}
					}
				</style>";
	  		}		

		}	
	}



	/* =================================================================
    = Header 1 Top Part
    ====================================================================*/
	public function Header1_Top_Color() {

  		if(function_exists( 'geoport_framework_init' ) ) {
		    $h1top_bg_color = geoport_get_option( 'h1top_bg_color' );
		    if (!empty($h1top_bg_color)) {
		      $h1top_bg_color = $h1top_bg_color;
		    } else {
		      $h1top_bg_color = 'transparent';
		    }
		    $h1top_font_color = geoport_get_option( 'h1top_font_color' );
		    if (!empty($h1top_font_color)) {
		      $h1top_font_color = $h1top_font_color;
		    } else {
		      $h1top_font_color = '#ffffff';
		    }
		    $h1top_hover_font_color = geoport_get_option( 'h1top_hover_font_color' );
		    if (!empty($h1top_hover_font_color)) {
		      $h1top_hover_font_color = $h1top_hover_font_color;
		    } else {
		      $h1top_hover_font_color = '#ff5e14';
		    }
		    $h1top_border_color = geoport_get_option( 'h1top_border_color' );
		    if (!empty($h1top_border_color)) {
		      $h1top_border_color = $h1top_border_color;
		    } else {
		      $h1top_border_color = 'rgba(255,255,255,.2)';
		    }

		    if ( !empty($h1top_bg_color )) {
		    	$padding = 'padding: 15px';
		    } else {
		    	$padding = 'padding: 15px 0';
		    }

		    echo "<style>
				/* = Header 1 Top Color = */
				.default-header .header-top-area .header-social a,
				.default-header .header-top-area ul li a {
				    color: $h1top_font_color;
				}
				.default-header .header-top-area {
					$padding;
					background-color: $h1top_bg_color;
					border-color: $h1top_border_color;
				}
				.default-header .header-top-area .header-social a:hover,
				.default-header .header-top-area ul li a:hover {
					color: $h1top_hover_font_color;
				}
		    </style>";
  		}		
	}



	/* =================================================================
    = Header 2 Top Part
    ====================================================================*/
	public function Header2_Top_Color() {

  		if(function_exists( 'geoport_framework_init' ) ) {

		    $h2top_font_color = geoport_get_option( 'h2top_font_color' );
		    if ( !empty($h2top_font_color )) {
		    	$h2top_font_color = $h2top_font_color;
		    } else {
		    	$h2top_font_color = '#ffffff';
		    }
		    $h2top_bg_color = geoport_get_option( 'h2top_bg_color' );
		    if ( !empty($h2top_bg_color )) {
		    	$h2top_bg_color = $h2top_bg_color;
		    } else {
		    	$h2top_bg_color = '#001d67';
		    }
		    $h2top_hover_font_color = geoport_get_option( 'h2top_hover_font_color' );
		    if ( !empty($h2top_hover_font_color )) {
		    	$h2top_hover_font_color = $h2top_hover_font_color;
		    } else {
		    	$h2top_hover_font_color = '#ff5e14';
		    }

		    echo "<style>
				/* = Header 2 Top Color = */
				.header-style-two .header-top-area .header-social a,
				.header-style-two .header-top-area ul li a {
				    color: $h2top_font_color;
				}
				.header-style-two .header-top-area {
					background-color: $h2top_bg_color;
				}
				.header-style-two .header-top-area .header-social a:hover,
				.header-style-two .header-top-area ul li a:hover {
					color: $h2top_hover_font_color;
				}
		    </style>";
  		}		
	}



	/* =================================================================
    = Breadcrumb settings
    ====================================================================*/
	public function Breadcrumb_Settings() {

  		if(function_exists( 'geoport_framework_init' ) ) {
  			// Breadcrumb settings
		    $breadcrumb_bg_condition = geoport_get_option( 'breadcrumb_bg_condition' );

		    $breadcrumb_bg_color = geoport_get_option( 'breadcrumb_bg_color' );
		    if (!empty($breadcrumb_bg_color)) {
		      $breadcrumb_bg_color = $breadcrumb_bg_color;
		    } else {
		      $breadcrumb_bg_color = '#000e30';
		    }

		    $breadcrumb_font_color = geoport_get_option( 'breadcrumb_font_color' );
		    if (!empty($breadcrumb_font_color)) {
		      $breadcrumb_font_color = $breadcrumb_font_color;
		    } else {
		      $breadcrumb_font_color = '#fff';
		    }
		    $breadcrumb_hover_link_color = geoport_get_option( 'breadcrumb_hover_link_color' );
		    if (!empty($breadcrumb_hover_link_color)) {
		      $breadcrumb_hover_link_color = $breadcrumb_hover_link_color;
		    } else {
		      $breadcrumb_hover_link_color = '#ff566e';
		    }
		    
		    $breadcrumb_pt = geoport_get_option( 'breadcrumb_pt' );
		    if (!empty($breadcrumb_pt)) {
		      $breadcrumb_pt = $breadcrumb_pt;
		    } else {
		      $breadcrumb_pt = '140px';
		    }
		    $breadcrumb_pb = geoport_get_option( 'breadcrumb_pb' );
		    if (!empty($breadcrumb_pb)) {
		      $breadcrumb_pb = $breadcrumb_pb;
		    } else {
		      $breadcrumb_pb = '75px';
		    }
		    
		    $breadcrumb_overlay_color = geoport_get_option( 'breadcrumb_overlay_color' );
		    if (!empty($breadcrumb_overlay_color)) {
		      $breadcrumb_overlay_color = $breadcrumb_overlay_color;
		    } else {
		      $breadcrumb_overlay_color = '#000927';
		    }
		   	
		    $breadcrumb_bg_img_opacity = geoport_get_option( 'breadcrumb_bg_img_opacity' );
		    if (!empty($breadcrumb_bg_img_opacity)) {
		      $breadcrumb_bg_img_opacity = $breadcrumb_bg_img_opacity;
		    } else {
		      $breadcrumb_bg_img_opacity = '.7';
		    }

		    $page_breadcrumb_color_data = get_post_meta( get_the_ID(), '_custom_page_options', true );

		    if (!empty($page_breadcrumb_color_data['page_breadcrumb_switch'])) {
		        if (!empty($page_breadcrumb_color_data['page_breadcrumb_bg_color'])) {
		          $breadcrumb_overlay_color = $page_breadcrumb_color_data['page_breadcrumb_bg_color'];
		        } else {
		          $breadcrumb_overlay_color = $breadcrumb_overlay_color;
		        }
		        if (!empty($page_breadcrumb_color_data['breadcrumb_bg_img_opacity'])) {
		          $breadcrumb_bg_img_opacity = $page_breadcrumb_color_data['breadcrumb_bg_img_opacity'];
		        } else {
		          $breadcrumb_bg_img_opacity = $breadcrumb_bg_img_opacity;
		        }
		        if (!empty($page_breadcrumb_color_data['breadcrumb_pt'])) {
		          $breadcrumb_pt = $page_breadcrumb_color_data['breadcrumb_pt'];
		        } else {
		          $breadcrumb_pt = $breadcrumb_pt;
		        }
		        if (!empty($page_breadcrumb_color_data['breadcrumb_pb'])) {
		          $breadcrumb_pb = $page_breadcrumb_color_data['breadcrumb_pb'];
		        } else {
		          $breadcrumb_pb = $breadcrumb_pb;
		        }
		        if (!empty($page_breadcrumb_color_data['breadcrumb_font_color'])) {
		          $breadcrumb_font_color = $page_breadcrumb_color_data['breadcrumb_font_color'];
		        } else {
		          $breadcrumb_font_color = $breadcrumb_font_color;
		        }
		        if (!empty($page_breadcrumb_color_data['breadcrumb_hover_link_color'])) {
		          $breadcrumb_hover_link_color = $page_breadcrumb_color_data['breadcrumb_hover_link_color'];
		        } else {
		          $breadcrumb_hover_link_color = $breadcrumb_hover_link_color;
		        }
		    } else {
		        $breadcrumb_pt = $breadcrumb_pt;
		        $breadcrumb_pb = $breadcrumb_pb;
		        $breadcrumb_font_color = $breadcrumb_font_color;
		        $breadcrumb_overlay_color = $breadcrumb_overlay_color;
		        $breadcrumb_bg_img_opacity = $breadcrumb_bg_img_opacity;
		        $breadcrumb_hover_link_color = $breadcrumb_hover_link_color;
		    }

		    if ( $breadcrumb_bg_condition != 'image' ) {
		      $breadcrumb_area = ".breadcrumb-area {
		        padding-top: $breadcrumb_pt;
		        margin-bottom: $breadcrumb_pb;
		        background: $breadcrumb_bg_color;
		      }";
		    } else {
		       $breadcrumb_area = ".breadcrumb-content {
		        padding-top: $breadcrumb_pt;
		        margin-bottom: $breadcrumb_pb;
		      }";
		    }

		    if ( $breadcrumb_bg_condition != 'image' ) {
		      $breadcrumb_area = ".breadcrumb-area {
		        padding-top: $breadcrumb_pt;
		        margin-bottom: $breadcrumb_pb;
		        background: $breadcrumb_bg_color;
		      }";
		    } else {
		       $breadcrumb_area = ".breadcrumb-content {
		        padding-top: $breadcrumb_pt;
		        margin-bottom: $breadcrumb_pb;
		      }";
		    }

		    $breadcrumb_title_font = geoport_get_option( 'breadcrumb_title_font' );
		    if (!empty($breadcrumb_title_font)) {
		      $breadcrumb_title_font = $breadcrumb_title_font;
		    } else {
		      $breadcrumb_title_font = '36px';
		    }

		    $breadcrumb_m_pt = geoport_get_option( 'breadcrumb_m_pt' );
		    if (!empty($breadcrumb_m_pt)) {
		      $breadcrumb_m_pt = $breadcrumb_m_pt;
		    } else {
		      $breadcrumb_m_pt = '200px';
		    }
		    $breadcrumb_m_pb = geoport_get_option( 'breadcrumb_m_pb' );
		    if (!empty($breadcrumb_m_pb)) {
		      $breadcrumb_m_pb = $breadcrumb_m_pb;
		    } else {
		      $breadcrumb_m_pb = '75px';
		    }

		    $breadcrumb_m_title_font = geoport_get_option( 'breadcrumb_m_title_font' );
		    if (!empty($breadcrumb_m_title_font)) {
		      $breadcrumb_m_title_font = $breadcrumb_m_title_font;
		    } else {
		      $breadcrumb_m_title_font = '32px';
		    }

		    echo "<style>
				/* = Breadcrumb Color = */
				$breadcrumb_area
				.breadcrumb-area.breadcrumb_height .breadcrumb-item + .breadcrumb-item::before,
				.breadcrumb-area.breadcrumb_height .breadcrumb-wrap h2,
				.breadcrumb-area.breadcrumb_height .breadcrumb li a, 
				.breadcrumb-area.breadcrumb_height .breadcrumb li,
				.breadcrumb-item + .breadcrumb-item::before {
					color: $breadcrumb_font_color;
				}
				.image-overlay:before {
					opacity: $breadcrumb_bg_img_opacity;
					background-color: $breadcrumb_overlay_color;
				}
				.breadcrumb li a:hover {
					color: $breadcrumb_hover_link_color !important;
				}
				.breadcrumb-content h2 {
					font-size: $breadcrumb_title_font;
				}
				@media (max-width: 767px) {
					.breadcrumb-content {
					    padding-top: $breadcrumb_m_pt;
					    margin-bottom: $breadcrumb_m_pb;
					}
					.breadcrumb-content h2 {
						font-size: $breadcrumb_m_title_font;
					}
				}
		    </style>";

  		}		
	}	


	/* =================================================================
    = Theme base color settings
    ====================================================================*/
	public function Theme_Base_Color_Settings() {

  		if(function_exists( 'geoport_framework_init' ) ) {
  			/* Color theme options */
		    $base_color = geoport_get_option( 'geoport_base_color' );
		    if (!empty($base_color)) {
		      $base_color = $base_color;
		    } else {
		      $base_color = '#ff5e14';
		    }

		    echo "<style>
				/* = Theme Base Color = */
				footer .widget_nav_menu ul li:hover> a,
				.bpost-meta a:hover,
				.bpost-meta ul li i,
				p.logged-in-as a,
				p.logged-in-as a {
					color: $base_color;
				}

				.ws-input input:focus {
					outline-color: $base_color;
				}

				.ws-input input:focus {
					border-color: $base_color;
				}
				
				.widget_recent_comments ul li:hover::before, 
				.widget_recent_entries ul li:hover::before, 
				.widget_categories ul li:hover::before, 
				.widget_nav_menu ul li:hover::before, 
				.widget_archive ul li:hover::before, 
				.widget_pages ul li:hover::before, 
				.widget_meta ul li:hover::before,
				.btn.transparent-btn:hover {
					color: $base_color;
				}
		    </style>";

  		}		
	}



	/* =================================================================
    = Theme Preloader Color settings
    ====================================================================*/
	public function Theme_Pageloader_Settings() {

  		if(function_exists( 'geoport_framework_init' ) ) {
  			/* Spinner options */
		    $geoport_preloader_circle_color = geoport_get_option( 'geoport_preloader_circle_color' );
		    if (!empty($geoport_preloader_circle_color)) {
		      $geoport_preloader_circle_color = $geoport_preloader_circle_color;
		    } else {
		      $geoport_preloader_circle_color = 'rgba(0, 0, 0, 0.2)';
		    }

		     $geoport_preloader_circle_spine_color = geoport_get_option( 'geoport_preloader_circle_spine_color' );
		    if (!empty($geoport_preloader_circle_spine_color)) {
		      $geoport_preloader_circle_spine_color = $geoport_preloader_circle_spine_color;
		    } else {
		      $geoport_preloader_circle_spine_color = '#ff5e14';
		    }

		    /* Text options */
		    $preloader_color = geoport_get_option( 'geoport_preloader_color' );
		    if (!empty($preloader_color)) {
		      $preloader_color = $preloader_color;
		    } else {
		      $preloader_color = '#000000';
		    }
		    $geoport_preloader_watermark_color = geoport_get_option( 'geoport_preloader_watermark_color' );
		    if (!empty($geoport_preloader_watermark_color)) {
		      $geoport_preloader_watermark_color = $geoport_preloader_watermark_color;
		    } else {
		      $geoport_preloader_watermark_color = 'rgba(0, 0, 0, 0.2)';
		    }
		    $geoport_preloader_bg_color = geoport_get_option( 'geoport_preloader_bg_color' );
		    if (!empty($geoport_preloader_bg_color)) {
		      $geoport_preloader_bg_color = $geoport_preloader_bg_color;
		    } else {
		      $geoport_preloader_bg_color = '#ffffff';
		    }

		    echo "<style>
				/* = Preloader Color = */
				.ctn-preloader .animation-preloader .spinner {
					border-color: $geoport_preloader_circle_color;
					border-top-color: $geoport_preloader_circle_spine_color;
				}
				.ctn-preloader .loader .loader-section .bg {
		        	background-color: $geoport_preloader_bg_color;
		      	}
		      	.ctn-preloader .animation-preloader .txt-loading .letters-loading {
		      		color: $geoport_preloader_watermark_color;
		      	}
		      	.ctn-preloader .animation-preloader .txt-loading .letters-loading:before {
		        	color: $preloader_color;
		      	}
		    </style>";

  		}		
	}	



	/* =================================================================
    = Theme Scrollup Color settings
    ====================================================================*/
	public function Theme_scrollup_Settings() {

  		if(function_exists( 'geoport_framework_init' ) ) {

  			$geoport_scroll_top_bg_color = geoport_get_option( 'geoport_scroll_top_bg_color' );
		    if (!empty($geoport_scroll_top_bg_color)) {
		      $geoport_scroll_top_bg_color = $geoport_scroll_top_bg_color;
		    } else {
		      $geoport_scroll_top_bg_color = '#39bdb2';
		    }
		    $geoport_scroll_top_font_color = geoport_get_option( 'geoport_scroll_top_font_color' );
		    if (!empty($geoport_scroll_top_font_color)) {
		      $geoport_scroll_top_font_color = $geoport_scroll_top_font_color;
		    } else {
		      $geoport_scroll_top_font_color = '#ffffff';
		    }
		    $geoport_scroll_top_border_radius = geoport_get_option( 'geoport_scroll_top_border_radius' );
		    if (!empty($geoport_scroll_top_border_radius)) {
		      $geoport_scroll_top_border_radius = $geoport_scroll_top_border_radius.'%';
		    } else {
		      $geoport_scroll_top_border_radius = '50'. '%';
		    }


		    echo "<style>
				/* = Scrollup Color = */
				#scroller {
			        color: $geoport_scroll_top_font_color;
			        background-color: $geoport_scroll_top_bg_color;
			        border-radius: $geoport_scroll_top_border_radius;
			    }
		    </style>";

  		}		
	}	




	/* =================================================================
    = Theme Footer Settings
    ====================================================================*/
	public function Theme_Footer_Settings() {

  		if(function_exists( 'geoport_framework_init' ) ) {

			$footer_background_color = geoport_get_option( 'footer_background_color' );
		    if (!empty($footer_background_color)) {
		      $footer_background_color = $footer_background_color;
		    } else {
		      $footer_background_color = '#001447';
		    }

			$ft_fonts_color = geoport_get_option( 'ft_fonts_color' );
		    if (!empty($ft_fonts_color)) {
		      $ft_fonts_color = $ft_fonts_color;
		    } else {
		      $ft_fonts_color = '#ffffff';
		    }

		    $ft_fonts_size = geoport_get_option( 'ft_fonts_size' );
		    if (!empty($ft_fonts_size)) {
		      $ft_fonts_size = $ft_fonts_size;
		    } else {
		      $ft_fonts_size = '34px';
		    }
  			
		    $footer_fonts_color = geoport_get_option( 'footer_fonts_color' );
		    if (!empty($footer_fonts_color)) {
		      $footer_fonts_color = $footer_fonts_color;
		    } else {
		      $footer_fonts_color = '';
		    }

		    $footer_copyright_background_color = geoport_get_option( 'footer_copyright_background_color' );
		    if (!empty($footer_copyright_background_color)) {
		      $footer_copyright_background_color = $footer_copyright_background_color;
		    } else {
		      $footer_copyright_background_color = '#001d67';
		    }

		    $footer_copyright_text_color = geoport_get_option( 'footer_copyright_text_color' );
		    if (!empty($footer_copyright_text_color)) {
		      $footer_copyright_text_color = $footer_copyright_text_color;
		    } else {
		      $footer_copyright_text_color = '#a7b6d3';
		    }

		    $footer_copyright_link_color = geoport_get_option( 'footer_copyright_link_color' );
		    if (!empty($footer_copyright_link_color)) {
		      $footer_copyright_link_color = $footer_copyright_link_color;
		    } else {
		      $footer_copyright_link_color = '#ff5e14';
		    }
		    
		    $footer_copyright_linkhv_color = geoport_get_option( 'footer_copyright_linkhv_color' );
		    if (!empty($footer_copyright_linkhv_color)) {
		      $footer_copyright_linkhv_color = $footer_copyright_linkhv_color;
		    } else {
		      $footer_copyright_linkhv_color = '#ff5e14';
		    }
		   
		    $footer_hover_link_color = geoport_get_option( 'footer_hover_link_color' );
		    if (!empty($footer_hover_link_color)) {
		      $footer_hover_link_color = $footer_hover_link_color;
		    } else {
		      $footer_hover_link_color = '';
		    }

		    // Footer Social
		   
			$footer_left_social_font_color = geoport_get_option( 'footer_left_social_font_color' );
		    if (!empty($footer_left_social_font_color)) {
		      $footer_left_social_font_color = $footer_left_social_font_color;
		    } else {
		      $footer_left_social_font_color = '#ffffff';
		    }

		    $footer_left_social_bg_color = geoport_get_option( 'footer_left_social_bg_color' );
		    if (!empty($footer_left_social_bg_color)) {
		      $footer_left_social_bg_color = $footer_left_social_bg_color;
		    } else {
		      $footer_left_social_bg_color = 'rgb(255, 255, 255, 0.102)';
		    }

		    $footer_left_social_h_font_color = geoport_get_option( 'footer_left_social_h_font_color' );
		    if (!empty($footer_left_social_h_font_color)) {
		      $footer_left_social_h_font_color = $footer_left_social_h_font_color;
		    } else {
		      $footer_left_social_h_font_color = '#ffffff';
		    }

		    $footer_left_social_h_bg_color = geoport_get_option( 'footer_left_social_h_bg_color' );
		    if (!empty($footer_left_social_h_bg_color)) {
		      $footer_left_social_h_bg_color = $footer_left_social_h_bg_color;
		    } else {
		      $footer_left_social_h_bg_color = '#34ccff';
		    }

		    echo "<style>
				/* = Footer Color = */
				.footer-bg {
			        color: $footer_fonts_color;
			        background-color: $footer_background_color;
			    }
			    footer .geoport_rp_widget .widget-title h4,
			    .footer-widget-title h4 {
					color: $ft_fonts_color;
					font-size: $ft_fonts_size;
			    }
			    footer .widget_nav_menu ul li:before,
			    .footer-work-hour-content p span,
			    footer .widget_nav_menu ul li a,
			    .footer-work-hour-content p,
			    .footer-work-hour-content a,
			    .footer-work-hour ul li{
			        color: $footer_fonts_color;
			    }
			    footer .widget_nav_menu ul li a:hover,
			    .footer-work-hour-content a:hover{
			        color: $footer_hover_link_color;
			    }

			    .copyright-text {
			    	background-color: $footer_copyright_background_color;
			    }
			    .copyright-text p {
			        color: $footer_copyright_text_color;
			    }
			    .copyright-text p a {
			        color: $footer_copyright_link_color;
			    }
			    .copyright-text p a:hover {
			        color: $footer_copyright_linkhv_color;
			    }

			    /* = Footer Color = */
			    footer .geoport_rp_widget.footer-widget .rc-post-content h5,
			    .footer-text p {
			    	color: $footer_fonts_color;
			    }
			    .footer-social ul li a {
					color: $footer_left_social_font_color;
					background-color: $footer_left_social_bg_color;
			    }
			    .footer-social ul li a:hover {
					color: $footer_left_social_h_font_color;
					background-color: $footer_left_social_h_bg_color;
			    }

		    </style>";

  		}		
	}	

	
} // end class

$GLOBALS['geoport_master_core'] = new Geoport_Master_Core;

function geoport_master_global_var(){
	global $geoport_master_core;
	return $geoport_master_core;
}
