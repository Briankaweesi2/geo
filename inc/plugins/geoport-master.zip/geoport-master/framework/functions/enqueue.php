<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
/**
 *
 * Framework admin enqueue style and scripts
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if( ! function_exists( 'geoport_admin_enqueue_scripts' ) ) {
  function geoport_admin_enqueue_scripts() {

    // admin utilities
    wp_enqueue_media();

    // wp core styles
    wp_enqueue_style( 'wp-color-picker' );
    wp_enqueue_style( 'wp-jquery-ui-dialog' );

    // framework core styles
    wp_enqueue_style( 'geoport-framework', GEOPORT_URI .'/assets/css/geoport-framework.css', array(), '1.0.0', 'all' );
    wp_enqueue_style( 'font-awesome', GEOPORT_URI .'/assets/css/font-awesome.css', array(), '4.7.0', 'all' );

    if ( GEOPORT_ACTIVE_LIGHT_THEME ) {
      wp_enqueue_style( 'geoport-framework-theme', GEOPORT_URI .'/assets/css/geoport-framework-light.css', array(), "1.0.0", 'all' );
    }

    if ( is_rtl() ) {
      wp_enqueue_style( 'geoport-framework-rtl', GEOPORT_URI .'/assets/css/geoport-framework-rtl.css', array(), '1.0.0', 'all' );
    }

    // wp core scripts
    wp_enqueue_script( 'wp-color-picker' );
    wp_enqueue_script( 'jquery-ui-dialog' );
    wp_enqueue_script( 'jquery-ui-sortable' );
    wp_enqueue_script( 'jquery-ui-accordion' );

    // framework core scripts
    wp_enqueue_script( 'geoport-plugins',    GEOPORT_URI .'/assets/js/geoport-plugins.js',    array(), '1.0.0', true );
    wp_enqueue_script( 'geoport-framework',  GEOPORT_URI .'/assets/js/geoport-framework.js',  array( 'geoport-plugins' ), '1.0.0', true );

  }
  add_action( 'admin_enqueue_scripts', 'geoport_admin_enqueue_scripts' );
}
