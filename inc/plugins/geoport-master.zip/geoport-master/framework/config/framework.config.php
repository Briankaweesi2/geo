<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK SETTINGS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$settings           = array(
  'menu_title'      => __( 'Geoport Options', 'geoport' ),
  'menu_type'       => 'menu', // menu, submenu, options, theme, etc.
  'menu_slug'       => 'geoport-framework',
  'ajax_save'       => true,
  'show_reset_all'  => false,
  'framework_title' => __( 'Geoport <small>by Johanspond</small>', 'geoport' ),
);

// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options        = array();

// ===================================================================
// Genaral Settings =
// ===================================================================

$options[]   = array(
  'name'     => 'general_setting',
  'title'    => __( 'General Settings', 'geoport' ),
  'icon'     => 'fal fa-home-heart',
  'sections' => array(
    // Logo & Site Icon
    array(
      'name'     => 'logo_and_site_icon',
      'title'    => 'Logo & site icon settings',
      'icon'     => 'fal fa-plus',
      'fields'   => array(

        array(
          'type'       => 'heading',
          'content'    => __( 'Site Icon Settings', 'geoport' ),
        ),
        array(
          'id'         => 'geoport_site_icon',
          'type'       => 'image',
          'title'      => __( 'Upload Favicon Icon', 'geoport' ),
          'default'    => GEOPORT_PLG_URL. 'assets/imgs/favicon.png',
          'desc'       => __( 'Site Icons should be square and Recommended size is 32 × 32 pixels.', 'geoport' ),
        ),

        array(
          'type'       => 'heading',
          'content'    => __( 'Logo Settings', 'geoport' ),
        ),
        array(
          'type'       => 'subheading',
          'content'    => __( 'logo 1', 'geoport' ),
        ),
        array(
          'id'         => 'geoport_logo1_img',
          'type'       => 'image',
          'title'      => __( 'Logo 1', 'geoport' ),
          'default'    => GEOPORT_PLG_URL. 'assets/imgs/logo1.png',
          'desc'       => __( 'Recommended image size is 200x60 png file', 'geoport' ),
        ),
        array(
          'id'         => 'geoport_logo1_sticky',
          'type'       => 'image',
          'title'      => __( 'Logo 1 sticky', 'geoport' ),
          'default'    => GEOPORT_PLG_URL. 'assets/imgs/logo1-sticky.png',
          'desc'       => __( 'Recommended image size is 200x60 png file', 'geoport' ),
        ),
        array(
          'id'         => 'geoport_logo1_width',
          'type'       => 'text',
          'title'      => __( 'Logo 1 width', 'geoport' ),
          'default'    => '200px',
          'desc'       => __( 'Put logo width as like as default value', 'geoport' ),
        ),
        array(
          'id'         => 'geoport_logo1_pt',
          'type'       => 'text',
          'title'      => __( 'Logo 1 padding top', 'geoport' ),
          'default'    => '15px',
          'desc'       => __( 'Put logo padding top like as default value', 'geoport' ),
        ),
         array(
          'id'         => 'geoport_logo1_pb',
          'type'       => 'text',
          'title'      => __( 'Logo 1 padding bottom', 'geoport' ),
          'default'    => '5px',
          'desc'       => __( 'Put logo padding top like as default value', 'geoport' ),
        ),

        array(
          'type'       => 'subheading',
          'content'    => __( 'Logo 2', 'geoport' ),
        ),
        array(
          'id'         => 'geoport_logo2_img',
          'type'       => 'image',
          'title'      => __( 'Logo 2', 'geoport' ),
          'default'    => GEOPORT_PLG_URL. 'assets/imgs/logo2.png',
          'desc'       => __( 'Recommended image size is 180x60 png file', 'geoport' ),
        ),
        array(
          'id'         => 'geoport_logo2_sticky',
          'type'       => 'image',
          'title'      => __( 'Logo 2 sticky', 'geoport' ),
          'default'    => GEOPORT_PLG_URL. 'assets/imgs/logo2-sticky.png',
          'desc'       => __( 'Recommended image size is 180x60 png file', 'geoport' ),
        ),
        array(
          'id'         => 'geoport_logo2_width',
          'type'       => 'text',
          'title'      => __( 'Logo 2 width', 'geoport' ),
          'default'    => '200px',
          'desc'       => __( 'Put logo width as like as default value', 'geoport' ),
        ),
        array(
          'id'         => 'geoport_logo2_pt',
          'type'       => 'text',
          'title'      => __( 'Logo 2 padding top', 'geoport' ),
          'default'    => '15px',
          'desc'       => __( 'Put logo padding top like as default value', 'geoport' ),
        ),
         array(
          'id'         => 'geoport_logo2_pb',
          'type'       => 'text',
          'title'      => __( 'Logo 2 padding bottom', 'geoport' ),
          'default'    => '5px',
          'desc'       => __( 'Put logo padding top like as default value', 'geoport' ),
        ),


      )
    ),
    // Breadcrumb
    array(
      'name'     => 'breadcrumb_settings',
      'title'    => 'Breadcrumb settings',
      'icon'     => 'fal fa-plus',
      'fields'   => array(

        array(
          'type'       => 'heading',
          'content'    => __( 'Breadcrumb Settings', 'geoport' ),
        ),
        array(
          'id'         => 'geoport_breadcrumb_switch',
          'type'       => 'switcher',
          'title'      => __( 'Breadcrumb Enable/Disable Switch', 'geoport' ),
          'default'    => true,
        ),
        array(
          'id'         => 'breadcrumb_bg_condition',
          'type'       => 'select',
          'title'      => __( 'Select Background image/color', 'geoport' ),
          'options'    => array(
            'image'    => 'Image',
            'color'    => 'Color',
          ),
          'default'    => 'image',
          'dependency' => array( 'geoport_breadcrumb_switch', '==', 'true' ),
        ),

        array(
          'id'         => 'breadcrumb_bg_img',
          'type'       => 'image',
          'title'      => __( 'Breadcrumb Image', 'geoport' ),
          'default'    => GEOPORT_PLG_URL. 'assets/imgs/breadcrumb.jpg',
          'desc'       => __( 'Recommended image size is 1920x400 jpg/png file, for secondary header', 'geoport' ),
          'dependency' => array( 'breadcrumb_bg_condition', '==', 'image' ),
        ),
        array(
          'id'         => 'breadcrumb_overlay_color',
          'type'       => 'color_picker',
          'title'      => __( 'Breadcrumb image overlay color', 'geoport' ),
          'desc'      => __( 'It is breadcrumb overlay color.', 'geoport' ),
          'default'    => '#000e30',
          'dependency' => array( 'breadcrumb_bg_condition', '==', 'image' ),
        ),
        array(
          'id'      => 'breadcrumb_bg_img_opacity',
          'type'    => 'select',
          'title'   => __( 'Breadcrumb Image Opacity', 'geoport' ),
          'options'      => array(
            '0' => '0',
            '0.2' => '0.2',
            '0.3' => '0.3',
            '0.4' => '0.4',
            '0.5' => '0.5',
            '0.6' => '0.6',
            '0.7' => '0.7',
            '0.8' => '0.8',
            '0.9' => '0.9',
            '1'   => '1',
          ),
          'default'        => '0.7',
          'dependency'   => array( 'breadcrumb_bg_condition', '==', 'image' ),
        ),
        array(
          'id'         => 'breadcrumb_bg_color',
          'type'       => 'color_picker',
          'title'      => __( 'Breadcrumb background color', 'geoport' ),
          'after'      => __( 'It is breadcrumb background color.', 'geoport' ),
          'default'    => '#000e30',
          'dependency' => array( 'breadcrumb_bg_condition', '!=', 'image' ),
        ),
        array(
          'id'      => 'breadcrumb_pt',
          'type'    => 'text',
          'title'   => __( 'Breadcrumb padding top', 'geoport' ),
          'desc'   => __( 'Breadcrumb padding top with px ( like as 350px ).', 'geoport' ),
          'default' => '260px',
          'dependency' => array( 'geoport_breadcrumb_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'breadcrumb_pb',
          'type'    => 'text',
          'title'   => __( 'Breadcrumb padding bottom', 'geoport' ),
          'desc'   => __( 'Breadcrumb padding bottom with px ( like as 350px ).', 'geoport' ),
          'default' => '115px',
          'dependency'   => array( 'geoport_breadcrumb_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'breadcrumb_title_font',
          'type'    => 'text',
          'title'   => __( 'Breadcrumb title font size', 'geoport' ),
          'desc'   => __( 'Breadcrumb padding bottom with px ( like as 350px ).', 'geoport' ),
          'default' => '42px',
          'dependency'   => array( 'geoport_breadcrumb_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'breadcrumb_font_color',
          'type'    => 'color_picker',
          'title'   => __( 'Breadcrumb font color', 'geoport' ),
          'desc'   => __( 'It is breadcrumb font color.', 'geoport' ),
          'default' => '#fff',
          'dependency'   => array( 'geoport_breadcrumb_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'breadcrumb_hover_link_color',
          'type'    => 'color_picker',
          'title'   => __( 'Breadcrumb hover link color', 'geoport' ),
          'desc'   => __( 'It is breadcrumb hover link font color.', 'geoport' ),
          'default' => '#ff5e14',
          'dependency'   => array( 'geoport_breadcrumb_switch', '==', 'true' ),
        ),
        array(
          'type'       => 'heading',
          'content'    => __( 'Responsive Breadcrumb', 'geoport' ),
        ),
        array(
          'id'      => 'breadcrumb_m_title_font',
          'type'    => 'text',
          'title'   => __( 'Breadcrumb title font size', 'geoport' ),
          'desc'   => __( 'Breadcrumb padding bottom with px ( like as 350px ).', 'geoport' ),
          'default' => '42px',
          'dependency'   => array( 'geoport_breadcrumb_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'breadcrumb_m_pt',
          'type'    => 'text',
          'title'   => __( 'Mobile padding top', 'geoport' ),
          'desc'   => __( 'Breadcrumb mobile device padding top with px ( like as 350px ).', 'geoport' ),
          'default' => '260px',
          'dependency' => array( 'geoport_breadcrumb_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'breadcrumb_m_pb',
          'type'    => 'text',
          'title'   => __( 'Mobile padding bottom', 'geoport' ),
          'desc'   => __( 'Breadcrumb mobile device padding bottom with px ( like as 50px ).', 'geoport' ),
          'default' => '115px',
          'dependency'   => array( 'geoport_breadcrumb_switch', '==', 'true' ),
        ),

      )
    ),

    // Pageloader & scroll to top
    array(
      'name'     => 'switcher_settings',
      'title'    => 'Switcher Settings',
      'icon'     => 'fal fa-plus',
      'fields'   => array(

        array(
          'type'       => 'heading',
          'content'    => __( 'Page Preloader', 'geoport' ),
        ),
        array(
          'id'         => 'geoport_preloader_enable',
          'type'       => 'switcher',
          'title'      => __( 'Preloader Switcher', 'geoport' ),
          'default'    => true,
        ),
        array(
          'type'       => 'subheading',
          'content'    => __( 'Spine Preloader', 'geoport' ),
          'dependency' => array( 'geoport_preloader_enable', '==', 'true' ),
        ),
        array(
          'id'         => 'geoport_spine_preloader_enable',
          'type'       => 'switcher',
          'title'      => __( 'Spine Preloader Switcher', 'geoport' ),
          'default'    => true,
          'dependency' => array( 'geoport_preloader_enable', '==', 'true' ),
        ),
        array(
          'id'         => 'geoport_preloader_circle_color',
          'type'       => 'color_picker',
          'title'      => __( 'Preloader circle color', 'geoport' ),
          'after'      => '<p class="cs-text-muted">It is preloader circle color.</p>',
          'default'    => 'rgba(0, 0, 0, 0.2)',
          'dependency' => array( 'geoport_preloader_enable|geoport_spine_preloader_enable', '==|==', 'true|true' ),
        ),
        array(
          'id'         => 'geoport_preloader_circle_spine_color',
          'type'       => 'color_picker',
          'title'      => __( 'Preloader circle spine color', 'geoport' ),
          'after'      => '<p class="cs-text-muted">It is preloader circle spine color.</p>',
          'default'    => '#ff5e14',
          'dependency' => array( 'geoport_preloader_enable|geoport_spine_preloader_enable', '==|==', 'true|true' ),
        ),

        // Text Preloader
        array(
          'type'       => 'subheading',
          'content'    => __( 'Text Preloader', 'geoport' ),
          'dependency' => array( 'geoport_preloader_enable', '==', 'true' ),
        ),
        array(
          'id'         => 'geoport_text_preloader_enable',
          'type'       => 'switcher',
          'title'      => __( 'Text Preloader Switcher', 'geoport' ),
          'default'    => true,
          'dependency' => array( 'geoport_preloader_enable', '==', 'true' ),
        ),
        array(
          'id'         => 'geoport_preloader_text',
          'type'       => 'text',
          'title'      => __( 'Preloader Text', 'geoport' ),
          'default'    =>  __( 'Geoport', 'geoport' ),
          'desc'       =>  __( 'Put loading texty without space', 'geoport' ),
          'dependency' => array( 'geoport_preloader_enable|geoport_text_preloader_enable', '==|==', 'true|true' ),
        ),
        array(
          'id'         => 'geoport_preloader_color',
          'type'       => 'color_picker',
          'title'      => __( 'Preloader text color', 'geoport' ),
          'after'      => '<p class="cs-text-muted">It is preloader color.</p>',
          'default'    => '#000000',
          'dependency' => array( 'geoport_preloader_enable|geoport_text_preloader_enable', '==|==', 'true|true' ),
        ),
        array(
          'id'         => 'geoport_preloader_watermark_color',
          'type'       => 'color_picker',
          'title'      => __( 'Preloader text bg watermark  color', 'geoport' ),
          'after'      => '<p class="cs-text-muted">It is watermark color.</p>',
          'default'    => 'rgba(0, 0, 0, 0.2)',
          'dependency' => array( 'geoport_preloader_enable|geoport_text_preloader_enable', '==|==', 'true|true' ),
        ),
        array(
          'id'         => 'geoport_preloader_bg_color',
          'type'       => 'color_picker',
          'title'      => __( 'Preloader background color', 'geoport' ),
          'after'      => '<p class="cs-text-muted">'.__( 'It is preloader background color.', 'geoport' ).'</p>',
          'default'    => '#ffffff',
          'dependency' => array( 'geoport_preloader_enable|geoport_text_preloader_enable', '==|==', 'true|true' ),
        ),

        // Scroll To Top Settings
        array(
          'type'       => 'heading',
          'content'    => __( 'Scroll to top', 'geoport' ),
        ),
        array(
          'id'         => 'geoport_scroll_top',
          'type'       => 'switcher',
          'title'      => __( 'Scroll to top on?', 'geoport' ),
        ),
        array(
          'id'         => 'geoport_scroll_top_icon',
          'type'       => 'icon',
          'title'      => __( 'Scroll to top icon', 'geoport' ),
          'after'      => '<p class="cs-text-muted">'.__( 'It is scroll to top icon.', 'geoport' ).'</p>',
          'default'    => 'far fa-level-up',
          'dependency' => array( 'geoport_scroll_top', '==', 'true' ),
        ),
        array(
          'id'         => 'geoport_scroll_top_bg_color',
          'type'       => 'color_picker',
          'title'      => __( 'Scroll to top background color', 'geoport' ),
          'after'      => '<p class="cs-text-muted">'.__( 'It is scroll to top background color.', 'geoport' ).'</p>',
          'default'    => '#ff5e14',
          'dependency' => array( 'geoport_scroll_top', '==', 'true' ),
        ),
        array(
          'id'         => 'geoport_scroll_top_font_color',
          'type'       => 'color_picker',
          'title'      => __( 'Scroll to top font color', 'geoport' ),
          'after'      => '<p class="cs-text-muted">'.__( 'It is scroll to top font color.', 'geoport' ).'</p>',
          'default'    => '#ffffff',
          'dependency' => array( 'geoport_scroll_top', '==', 'true' ),
        ),
        array(
          'id'         => 'geoport_scroll_top_border_radius',
          'type'       => 'number',
          'title'      => __( 'Border Radius', 'geoport' ),
          'default'    => '50',
          'desc'       => __( 'Put border radius 1-100, it count as a persantage', 'geoport' ),
          'validate'   => 'numeric',
          'dependency' => array( 'geoport_scroll_top', '==', 'true' ),
        ),

      )
    ),

  ),
);



// ===================================================================
// Typography Settings =
// ===================================================================

$options[]   = array(
  'name'     => 'typography_setting',
  'title'    => __( 'Typography Settings', 'geoport' ),
  'icon'     => 'fal fa-text-height',
  'sections' => array(

    // Body Typography
    array(
      'name'     => 'body_typography',
      'title'    => 'Body Typography',
      'icon'     => 'fal fa-plus',
      'fields'   => array(
        array(
          'type'    => 'heading',
          'content' => __( 'Site Font Settings', 'geoport' ),
        ),
        array(
          'id'           => 'geoport_body_font',
          'type'         => 'typography',
          'title'        => __( 'Body font', 'geoport' ),
          'default'   => array(
            'family'  => 'Karla',
            'font'    => 'google', // this is helper for output ( google, websafe, custom )
          ),
          'variant'   => false,
        ),
        array(
          'id'        => 'geoport_body_font_size',
          'type'      => 'text',
          'title'     => __( 'Body font size', 'geoport' ),
          'default'   => '16px',
        ),
        array(
          'id'        => 'line_height',
          'type'      => 'text',
          'title'     => __( 'Line Height', 'geoport' ),
          'default'   => '26px',
        ),

      )
    ),
    // Heading Typography
    array(
      'name'     => 'heading_typography',
      'title'    => 'Heading Typography',
      'icon'     => 'fal fa-plus',
      'fields'   => array(

        array(
          'id'           => 'geoport_heading_font',
          'type'         => 'typography',
          'title'        => __( 'Heading font', 'geoport' ),
          'default'   => array(
            'family'  => 'Montserrat',
            'font'    => 'google',
          ),
          'variant'   => false,
        ),
        
      )
    ),
    // Color Typography
    array(
      'name'     => 'color_typography',
      'title'    => 'Color Typography',
      'icon'     => 'fal fa-plus',
      'fields'   => array(

        array(
          'type'    => 'heading',
          'content' => __( 'Site Color Settings', 'geoport' ),
        ),
        array(
          'id'      => 'geoport_base_color',
          'type'    => 'color_picker',
          'title'   => __( 'Theme base color', 'geoport' ),
          'after'   => '<p class="cs-text-muted">It is theme base color.</p>',
          'default' => '#ff5e14',
        ),

      )
    ),

  ),
);



// ===================================================================
// Header Settings =
// ===================================================================
$options[]   = array(
  'name'     => 'header_setting',
  'title'    => __( 'Header Settings', 'geoport' ),
  'icon'     => 'fal fa-heading',
  'sections' => array(

    // Header top part 1
    array(
      'name'     => 'header_one',
      'title'    => 'Header 1',
      'icon'     => 'fal fa-plus',
      'fields'   => array(

        array(
          'type'    => 'heading',
          'content' =>  __( 'Header One Elements Setting', 'geoport' ),
          'dependency'   => array( 'top_header1', '==', 'true' ),
        ),

        array(
          'id'      => 'top_header1',
          'type'    => 'switcher',
          'title'   =>  __( 'Header Top Part On?', 'geoport' ),
          'desc'    => __( 'It work for header version 1', 'geoport' ),
        ),

        array(
          'type'    => 'subheading',
          'content' =>  __( 'Top Header Left List', 'geoport' ),
          'dependency'   => array( 'top_header1', '==', 'true' ),
        ),
        array(
          'id'              => 'header1_left_list',
          'type'            => 'group',
          'title'           =>  __( 'Header top left menu', 'geoport' ),
          'dependency'   => array( 'top_header1', '==', 'true' ),
          'button_title'    =>  __( 'Add New', 'geoport' ),
          'accordion_title' =>  __( 'Add New List', 'geoport' ),
          'fields'          => array(
            array(
              'id'          => 'list_text',
              'type'        => 'text',
              'title'       =>  __( 'Text', 'geoport' ),
            ),
            array(
              'id'          => 'list_link',
              'type'        => 'text',
              'title'       =>  __( 'Link', 'geoport' ),
            ),
            array(
              'id'          => 'list_icon',
              'type'        => 'icon',
              'title'       =>  __( 'Icon', 'geoport' ),
            ),
          ),
        ),

        array(
          'type'    => 'subheading',
          'content' =>  __( 'Top Header Right List', 'geoport' ),
          'dependency'   => array( 'top_header1', '==', 'true' ),
        ),
        array(
          'id'              => 'header1_right_list',
          'type'            => 'group',
          'title'           =>  __( 'Header top right menu', 'geoport' ),
          'dependency'   => array( 'top_header1', '==', 'true' ),
          'button_title'    =>  __( 'Add New', 'geoport' ),
          'accordion_title' =>  __( 'Add New List', 'geoport' ),
          'fields'          => array(
            array(
              'id'          => 'list_text',
              'type'        => 'text',
              'title'       =>  __( 'Text', 'geoport' ),
            ),
            array(
              'id'          => 'list_link',
              'type'        => 'text',
              'title'       =>  __( 'Link', 'geoport' ),
            ),
            array(
              'id'          => 'list_icon',
              'type'        => 'icon',
              'title'       =>  __( 'Icon', 'geoport' ),
            ),
          ),
        ),

        array(
          'type'    => 'subheading',
          'content' =>  __( 'Header social buttons', 'geoport' ),
          'dependency'   => array( 'top_header', '==', 'true' ),
        ),
        array(
          'id'              => 'header1_social_btn',
          'type'            => 'group',
          'title'           =>  __( 'Header Social Button', 'geoport' ),
          'dependency'      => array( 'top_header1', '==', 'true' ),
          'button_title'    =>  __( 'Add New', 'geoport' ),
          'accordion_title' =>  __( 'Add New Social Button', 'geoport' ),
          'fields'          => array(
            array(
              'id'          => 'social_icon',
              'type'        => 'icon',
              'title'       =>  __( 'Social Icon', 'geoport' ),
            ),
            array(
              'id'          => 'social_link',
              'type'        => 'text',
              'title'       =>  __( 'Link', 'geoport' ),
            ),
          ),
        ),

        // Color Settings
        array(
          'type'       => 'subheading',
          'content'    => __( 'Header top part color', 'geoport' ),
          'dependency' => array( 'top_header1', '==', 'true' ),
        ),
        array(
          'id'         => 'h1top_bg_color',
          'type'       => 'color_picker',
          'title'      => __( 'Menu background color', 'geoport' ),
          'dependency' => array( 'top_header1', '==', 'true' ),
        ),
        array(
          'id'         => 'h1top_font_color',
          'type'       => 'color_picker',
          'title'      => __( 'Top header 1 color', 'geoport' ),
          'default'    => '#ffffff',
          'dependency' => array( 'top_header1', '==', 'true' ),
        ),
        array(
          'id'         => 'h1top_hover_font_color',
          'type'       => 'color_picker',
          'title'      => __( 'Top header link hover color', 'geoport' ),
          'default'    => '#ff5e14',
          'dependency' => array( 'top_header1', '==', 'true' ),
        ),
        array(
          'id'         => 'h1top_border_color',
          'type'       => 'color_picker',
          'title'      => __( 'Top border color', 'geoport' ),
          'default'    => 'rgba(255,255,255,.2)',
          'dependency' => array( 'top_header1', '==', 'true' ),
        ),


      )
    ),

     // Header top part 2
    array(
      'name'     => 'header_two',
      'title'    => 'Header 2',
      'icon'     => 'fal fa-plus',
      'fields'   => array(

        array(
          'type'       => 'heading',
          'content'    =>  __( 'Header Two Elements Setting', 'geoport' ),
          'dependency' => array( 'top_header2', '==', 'true' ),
        ),

        array(
          'id'      => 'top_header2',
          'type'    => 'switcher',
          'title'   =>  __( 'Header Top Part On?', 'geoport' ),
          'desc'    => __( 'It work for header version 2', 'geoport' ),
        ),

        array(
          'type'       => 'subheading',
          'content'    =>  __( 'Top Header Left List', 'geoport' ),
          'dependency' => array( 'top_header2', '==', 'true' ),
        ),
        array(
          'id'              => 'header2_left_list',
          'type'            => 'group',
          'title'           =>  __( 'Header top left menu', 'geoport' ),
          'dependency'   => array( 'top_header2', '==', 'true' ),
          'button_title'    =>  __( 'Add New', 'geoport' ),
          'accordion_title' =>  __( 'Add New List', 'geoport' ),
          'fields'          => array(
            array(
              'id'          => 'list_text',
              'type'        => 'text',
              'title'       =>  __( 'Text', 'geoport' ),
            ),
            array(
              'id'          => 'list_link',
              'type'        => 'text',
              'title'       =>  __( 'Link', 'geoport' ),
            ),
            array(
              'id'          => 'list_icon',
              'type'        => 'icon',
              'title'       =>  __( 'Icon', 'geoport' ),
            ),
          ),
        ),

        array(
          'type'    => 'subheading',
          'content' =>  __( 'Top Header Right List', 'geoport' ),
          'dependency'   => array( 'top_header2', '==', 'true' ),
        ),
        array(
          'id'              => 'header2_right_list',
          'type'            => 'group',
          'title'           =>  __( 'Header top right menu', 'geoport' ),
          'dependency'   => array( 'top_header2', '==', 'true' ),
          'button_title'    =>  __( 'Add New', 'geoport' ),
          'accordion_title' =>  __( 'Add New List', 'geoport' ),
          'fields'          => array(
            array(
              'id'          => 'list_text',
              'type'        => 'text',
              'title'       =>  __( 'Text', 'geoport' ),
            ),
            array(
              'id'          => 'list_link',
              'type'        => 'text',
              'title'       =>  __( 'Link', 'geoport' ),
            ),
            array(
              'id'          => 'list_icon',
              'type'        => 'icon',
              'title'       =>  __( 'Icon', 'geoport' ),
            ),
          ),
        ),

        array(
          'type'    => 'subheading',
          'content' =>  __( 'Header social buttons', 'geoport' ),
          'dependency'   => array( 'top_header2', '==', 'true' ),
        ),
        array(
          'id'              => 'header2_social_btn',
          'type'            => 'group',
          'title'           =>  __( 'Header Social Button', 'geoport' ),
          'dependency'      => array( 'top_header2', '==', 'true' ),
          'button_title'    =>  __( 'Add New', 'geoport' ),
          'accordion_title' =>  __( 'Add New Social Button', 'geoport' ),
          'fields'          => array(
            array(
              'id'          => 'social_icon',
              'type'        => 'icon',
              'title'       =>  __( 'Social Icon', 'geoport' ),
            ),
            array(
              'id'          => 'social_link',
              'type'        => 'text',
              'title'       =>  __( 'Link', 'geoport' ),
            ),
          ),
        ),

        // Color Settings
        array(
          'type'       => 'subheading',
          'content'    => __( 'Header top part color', 'geoport' ),
          'dependency' => array( 'top_header2', '==', 'true' ),
        ),
        array(
          'id'         => 'h2top_font_color',
          'type'       => 'color_picker',
          'title'      => __( 'Top header 2 color', 'geoport' ),
          'default'    => '#ffffff',
          'dependency' => array( 'top_header2', '==', 'true' ),
        ),
        array(
          'id'         => 'h2top_bg_color',
          'type'       => 'color_picker',
          'title'      => __( 'Menu background color', 'geoport' ),
          'default'    => '#001d67',
          'dependency' => array( 'top_header2', '==', 'true' ),
        ),
        array(
          'id'         => 'h2top_hover_font_color',
          'type'       => 'color_picker',
          'title'      => __( 'Top header link hover color', 'geoport' ),
          'default'    => '#34ccff',
          'dependency' => array( 'top_header2', '==', 'true' ),
        ),

      )
    ),

    // Header top part 3
    array(
      'name'     => 'header_three',
      'title'    => 'Header 3',
      'icon'     => 'fal fa-plus',
      'fields'   => array(

        array(
          'type'    => 'heading',
          'content' =>  __( 'Header One Elements Setting', 'geoport' ),
          'dependency'   => array( 'top_header3', '==', 'true' ),
        ),

        array(
          'id'      => 'top_header3',
          'type'    => 'switcher',
          'title'   =>  __( 'Header Top Part On?', 'geoport' ),
          'desc'    => __( 'It work for header version 3', 'geoport' ),
        ),

        array(
          'type'    => 'subheading',
          'content' =>  __( 'Top Header Left List', 'geoport' ),
          'dependency'   => array( 'top_header3', '==', 'true' ),
        ),
        array(
          'id'              => 'header3_left_list',
          'type'            => 'group',
          'title'           =>  __( 'Header top left menu', 'geoport' ),
          'dependency'   => array( 'top_header3', '==', 'true' ),
          'button_title'    =>  __( 'Add New', 'geoport' ),
          'accordion_title' =>  __( 'Add New List', 'geoport' ),
          'fields'          => array(
            array(
              'id'          => 'list_text',
              'type'        => 'text',
              'title'       =>  __( 'Text', 'geoport' ),
            ),
            array(
              'id'          => 'list_link',
              'type'        => 'text',
              'title'       =>  __( 'Link', 'geoport' ),
            ),
            array(
              'id'          => 'list_icon',
              'type'        => 'icon',
              'title'       =>  __( 'Icon', 'geoport' ),
            ),
          ),
        ),

        array(
          'type'    => 'subheading',
          'content' =>  __( 'Top Header Right List', 'geoport' ),
          'dependency'   => array( 'top_header3', '==', 'true' ),
        ),
        array(
          'id'              => 'header3_right_list',
          'type'            => 'group',
          'title'           =>  __( 'Header top right menu', 'geoport' ),
          'dependency'   => array( 'top_header3', '==', 'true' ),
          'button_title'    =>  __( 'Add New', 'geoport' ),
          'accordion_title' =>  __( 'Add New List', 'geoport' ),
          'fields'          => array(
            array(
              'id'          => 'list_text',
              'type'        => 'text',
              'title'       =>  __( 'Text', 'geoport' ),
            ),
            array(
              'id'          => 'list_link',
              'type'        => 'text',
              'title'       =>  __( 'Link', 'geoport' ),
            ),
            array(
              'id'          => 'list_icon',
              'type'        => 'icon',
              'title'       =>  __( 'Icon', 'geoport' ),
            ),
          ),
        ),

        array(
          'type'    => 'subheading',
          'content' =>  __( 'Header social buttons', 'geoport' ),
          'dependency'   => array( 'top_header', '==', 'true' ),
        ),
        array(
          'id'              => 'header3_social_btn',
          'type'            => 'group',
          'title'           =>  __( 'Header Social Button', 'geoport' ),
          'dependency'      => array( 'top_header3', '==', 'true' ),
          'button_title'    =>  __( 'Add New', 'geoport' ),
          'accordion_title' =>  __( 'Add New Social Button', 'geoport' ),
          'fields'          => array(
            array(
              'id'          => 'social_icon',
              'type'        => 'icon',
              'title'       =>  __( 'Social Icon', 'geoport' ),
            ),
            array(
              'id'          => 'social_link',
              'type'        => 'text',
              'title'       =>  __( 'Link', 'geoport' ),
            ),
          ),
        ),

        // Color Settings
        array(
          'type'       => 'subheading',
          'content'    => __( 'Header top part color', 'geoport' ),
          'dependency' => array( 'top_header3', '==', 'true' ),
        ),
        array(
          'id'         => 'h3top_bg_color',
          'type'       => 'color_picker',
          'title'      => __( 'Menu background color', 'geoport' ),
          'dependency' => array( 'top_header3', '==', 'true' ),
        ),
        array(
          'id'         => 'h3top_font_color',
          'type'       => 'color_picker',
          'title'      => __( 'Top header 1 color', 'geoport' ),
          'default'    => '#ffffff',
          'dependency' => array( 'top_header3', '==', 'true' ),
        ),
        array(
          'id'         => 'h3top_hover_font_color',
          'type'       => 'color_picker',
          'title'      => __( 'Top header link hover color', 'geoport' ),
          'default'    => '#34ccff',
          'dependency' => array( 'top_header3', '==', 'true' ),
        ),
        array(
          'id'         => 'h3top_border_color',
          'type'       => 'color_picker',
          'title'      => __( 'Top border color', 'geoport' ),
          'default'    => 'rgba(255,255,255,.2)',
          'dependency' => array( 'top_header3', '==', 'true' ),
        ),


      )
    ),

    // Default Header Settings
    array(
      'name'     => 'default_header_settings',
      'title'    => 'Header Settings',
      'icon'     => 'fal fa-plus',
      'fields'   => array(

        array(
          'type'    => 'heading',
          'content' => __( 'Default header settings', 'geoport' ),
        ),
        array(
          'id'          => 'default_header_style',
          'type'        => 'image_select',
          'title'       => __( 'Select Default Header', 'geoport' ),
          'options'     => array(
            'style1'    => GEOPORT_PLG_URL. 'assets/imgs/header1.jpg',
            'style2'    => GEOPORT_PLG_URL. 'assets/imgs/header2.jpg',
            'style3'    => GEOPORT_PLG_URL. 'assets/imgs/header3.jpg',
          ),
          'desc'   => __( 'This is all default page header style if you select','geoport'),
        ),

        array(
          'id'          => 'default_h2_top',
          'type'        => 'text',
          'title'       =>  __( 'Header 2 padding top', 'geoport' ),
          'default'     => '290px',
          'dependency'  => array( 'default_header_style_style2', '==', 'true' ),
          'desc'        => __( 'When select header 2, you need to breadcrumb top padding reset if you feel need', 'geoport' ),
        ),
        array(
          'id'          => 'default_h2_bottom',
          'type'        => 'text',
          'title'       =>  __( 'Header 2 padding bottom', 'geoport' ),
          'default'     => '135px',
          'dependency'  => array( 'default_header_style_style2', '==', 'true' ),
          'desc'        => __( 'When select header 2, you need to breadcrumb bottom padding reset if you feel need', 'geoport' ),
        ),
        array(
          'id'          => 'default_h3_top',
          'type'        => 'text',
          'title'       =>  __( 'Header 3 padding top', 'geoport' ),
          'default'     => '325px',
          'dependency'  => array( 'default_header_style_style3', '==', 'true' ),
          'desc'        => __( 'When select header 3, you need to breadcrumb top padding reset if you feel need', 'geoport' ),
        ),
        array(
          'id'          => 'default_h3_bottom',
          'type'        => 'text',
          'title'       =>  __( 'Header 3 padding bottom', 'geoport' ),
          'default'     => '135px',
          'dependency'  => array( 'default_header_style_style3', '==', 'true' ),
          'desc'        => __( 'When select header 3, you need to breadcrumb bottom padding reset if you feel need', 'geoport' ),
        ),

      )
    ),

  ),
);



// ===================================================================
// Menu Settings =
// ===================================================================
$options[]   = array(
  'name'     => 'geoport_menu',
  'title'    => __( 'Menu Settings', 'geoport' ),
  'icon'     => 'fal fa-bars',
  'sections' => array(

    // All Menu
    array(
      'name'     => 'sticky_menu',
      'title'    => 'All menu',
      'icon'     => 'fal fa-plus',
      'fields'   => array(
        // Sticky menu
        array(
          'type'    => 'subheading',
          'content' => __( 'Sticky menu', 'geoport' ),
        ),
        array(
          'id'      => 'sticky_menu_switch',
          'type'    => 'switcher',
          'title'   =>  __( 'Sticky menu off?', 'geoport' ),
          'default' =>  true,
        ),
        array(
          'type'    => 'subheading',
          'content' => __( 'Menu Button', 'geoport' ),
        ),
        array(
          'id'      => 'menu_mobile_btn',
          'type'    => 'switcher',
          'title'   => __( 'Menu Mobile Button Enable', 'geoport' ),
          'desc'    => __( 'Button enable for mobile device', 'geoport' ),
        ),
       )
    ),

    // Menu 1
    array(
      'name'     => 'menu_1',
      'title'    => 'Menu Style 1 (defautl menu)',
      'icon'     => 'fal fa-plus',
      'fields'   => array(

        array(
          'type'    => 'subheading',
          'content' => __( 'Menu color', 'geoport' ),
        ),
        array(
          'id'      => 'menu1_bg_color',
          'type'    => 'color_picker',
          'title'   => __( 'Menu background color', 'geoport' ),
          'default' => 'transparent',
        ),
        array(
          'id'      => 'menu1_font_color',
          'type'    => 'color_picker',
          'title'   => __( 'Menu font color', 'geoport' ),
          'default' => '#ffffff',
        ),
        array(
          'id'      => 'menu1_hover_font_color',
          'type'    => 'color_picker',
          'title'   => __( 'Menu hover font color', 'geoport' ),
          'default' => '#ff5e14',
        ),

        // Menu 1 Submenu
        array(
          'type'    => 'subheading',
          'content' => __( 'Sub menu color', 'geoport' ),
        ),
        array(
          'id'      => 'submenu1_bg_color',
          'type'    => 'color_picker',
          'title'   => __( 'Background color', 'geoport' ),
          'default' => '#ffffff',
        ),
        array(
          'id'      => 'submenu1_color',
          'type'    => 'color_picker',
          'title'   => __( 'Font color', 'geoport' ),
          'default' => '#244b5a',
        ),
        array(
          'id'      => 'submenu1_hover_color',
          'type'    => 'color_picker',
          'title'   => __( 'Hover font color', 'geoport' ),
          'default' => '#ff5e14',
        ),
        array(
          'id'      => 'submenu1_border_color',
          'type'    => 'color_picker',
          'title'   => __( 'Border color', 'geoport' ),
          'default' => '#eceef0',
        ),

        // Language button
        array(
          'type'    => 'subheading',
          'content' => __( 'Language button', 'geoport' ),
        ),
        array(
          'id'      => 'lan1_btn_switch',
          'type'    => 'switcher',
          'title'   =>  __( 'Language button switcher', 'geoport' ),
        ),
        array(
          'id'      => 'lan1_btn_shortcode',
          'type'    => 'textarea',
          'title'   => __( 'language button shortcode', 'geoport' ),
          'desc'   => __( 'Put language button shortcode', 'geoport' ),
          'dependency' => array( 'lan1_btn_switch', '==', 'true' ),
        ),
        
        // Menu button
        array(
          'type'    => 'subheading',
          'content' => __( 'Menu button', 'geoport' ),
        ),
        array(
          'id'      => 'menu1_btn_switch',
          'type'    => 'switcher',
          'title'   =>  __( 'Menu button switcher', 'geoport' ),
          'default' =>  true,
        ),
        array(
          'id'      => 'menu1_btn_icon',
          'type'    => 'icon',
          'title'   => __( 'Button icon', 'geoport' ),
          'default' => 'fal fa-truck',
          'dependency' => array( 'menu1_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu1_btn_text',
          'type'    => 'text',
          'title'   => __( 'Button text', 'geoport' ),
          'default' => 'Track Your Order',
          'dependency' => array( 'menu1_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu1_btn_link',
          'type'    => 'text',
          'title'   => __( 'Button link', 'geoport' ),
          'default' => '#',
          'dependency' => array( 'menu1_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu1_btn_bg_color',
          'type'    => 'color_picker',
          'title'   => __( 'Background color', 'geoport' ),
          'default' => 'transparent',
          'dependency' => array( 'menu1_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu1_btn_font_color',
          'type'    => 'color_picker',
          'title'   => __( 'Font color', 'geoport' ),
          'default' => '#ffffff',
          'dependency' => array( 'menu1_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu1_btn_border_color',
          'type'    => 'color_picker',
          'title'   => __( 'Border color', 'geoport' ),
          'default' => 'rgba(255, 255, 255, 0.3)',
          'dependency' => array( 'menu1_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu1_btn_hf_color',
          'type'    => 'color_picker',
          'title'   => __( 'Hover font color', 'geoport' ),
          'default' => '#ffffff',
          'dependency' => array( 'menu1_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu1_btn_hb_color',
          'type'    => 'color_picker',
          'title'   => __( 'Hover background color', 'geoport' ),
          'default' => '#ff5e14',
          'dependency' => array( 'menu1_btn_switch', '==', 'true' ),
        ),

        // Sticky menu
        array(
          'type'    => 'subheading',
          'content' => __( 'Sticky menu color', 'geoport' ),
          'dependency' => array( 'sticky_menu_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'sticky_menu1_bg_color',
          'type'    => 'color_picker',
          'title'   => __( 'Menu background color', 'geoport' ),
          'default' => '#ffffff',
          'dependency' => array( 'sticky_menu_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'sticky_menu1_font_color',
          'type'    => 'color_picker',
          'title'   => __( 'Menu font color', 'geoport' ),
          'default' => '#244b5a',
          'dependency' => array( 'sticky_menu_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'sticky_menu1_hover_font_color',
          'type'    => 'color_picker',
          'title'   => __( 'Menu hover font color', 'geoport' ),
          'default' => '#ff5e14',
          'dependency' => array( 'sticky_menu_switch', '==', 'true' ),
        ),

      )
    ),

    // Menu 2
    array(
      'name'     => 'menu_2',
      'title'    => 'Menu Style 2',
      'icon'     => 'fal fa-plus',
      'fields'   => array(

        array(
          'type'    => 'subheading',
          'content' => __( 'Menu color', 'geoport' ),
        ),
        array(
          'id'      => 'menu2_bg_color',
          'type'    => 'color_picker',
          'title'   => __( 'Menu background color', 'geoport' ),
          'default' => '#ffffff',
        ),
        array(
          'id'      => 'menu2_font_color',
          'type'    => 'color_picker',
          'title'   => __( 'Menu font color', 'geoport' ),
          'default' => '#244b5a',
        ),
        array(
          'id'      => 'menu2_hover_font_color',
          'type'    => 'color_picker',
          'title'   => __( 'Menu hover font color', 'geoport' ),
          'default' => '#ff5e14',
        ),

        // Menu 2 Submenu
        array(
          'type'    => 'subheading',
          'content' => __( 'Sub menu color', 'geoport' ),
        ),
        array(
          'id'      => 'submenu2_bg_color',
          'type'    => 'color_picker',
          'title'   => __( 'Background color', 'geoport' ),
          'default' => '#ffffff',
        ),
        array(
          'id'      => 'submenu2_font_color',
          'type'    => 'color_picker',
          'title'   => __( 'Font color', 'geoport' ),
          'default' => '#244b5a',
        ),
        array(
          'id'      => 'submenu2_hover_font_color',
          'type'    => 'color_picker',
          'title'   => __( 'Hover font color', 'geoport' ),
          'default' => '#ff5e14',
        ),
        array(
          'id'      => 'submenu2_border_color',
          'type'    => 'color_picker',
          'title'   => __( 'Border color', 'geoport' ),
          'default' => '#eceef0',
        ),

        // Language button
        array(
          'type'    => 'subheading',
          'content' => __( 'Language button', 'geoport' ),
        ),
        array(
          'id'      => 'lan2_btn_switch',
          'type'    => 'switcher',
          'title'   =>  __( 'Language button switcher', 'geoport' ),
        ),
        array(
          'id'      => 'lan2_btn_shortcode',
          'type'    => 'textarea',
          'title'   => __( 'language button shortcode', 'geoport' ),
          'desc'   => __( 'Put language button shortcode', 'geoport' ),
          'dependency' => array( 'lan2_btn_switch', '==', 'true' ),
        ),
        
        // Menu button
        array(
          'type'    => 'subheading',
          'content' => __( 'Menu button', 'geoport' ),
        ),
        array(
          'id'      => 'menu2_btn_switch',
          'type'    => 'switcher',
          'title'   =>  __( 'Menu button switcher', 'geoport' ),
          'default' =>  true,
        ),
        array(
          'id'      => 'menu2_btn_icon',
          'type'    => 'icon',
          'title'   => __( 'Button icon', 'geoport' ),
          'default' => 'fal fa-truck',
          'dependency' => array( 'menu2_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu2_btn_text',
          'type'    => 'text',
          'title'   => __( 'Button text', 'geoport' ),
          'default' => 'Track Your Order',
          'dependency' => array( 'menu2_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu2_btn_link',
          'type'    => 'text',
          'title'   => __( 'Button link', 'geoport' ),
          'default' => '#',
          'dependency' => array( 'menu2_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu2_btn_bg_color',
          'type'    => 'color_picker',
          'title'   => __( 'Background color', 'geoport' ),
          'default' => 'transparent',
          'dependency' => array( 'menu2_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu2_btn_font_color',
          'type'    => 'color_picker',
          'title'   => __( 'Font color', 'geoport' ),
          'default' => '#244b5a',
          'dependency' => array( 'menu2_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu2_btn_border_color',
          'type'    => 'color_picker',
          'title'   => __( 'Border color', 'geoport' ),
          'default' => '#d7edff',
          'dependency' => array( 'menu2_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu2_btn_hf_color',
          'type'    => 'color_picker',
          'title'   => __( 'Hover font color', 'geoport' ),
          'default' => '#ffffff',
          'dependency' => array( 'menu2_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu2_btn_hb_color',
          'type'    => 'color_picker',
          'title'   => __( 'Hover background color', 'geoport' ),
          'default' => '#ff5e14',
          'dependency' => array( 'menu2_btn_switch', '==', 'true' ),
        ),

        // Sticky menu
        array(
          'type'    => 'subheading',
          'content' => __( 'Sticky menu color', 'geoport' ),
          'dependency' => array( 'sticky_menu_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'sticky_menu2_bg_color',
          'type'    => 'color_picker',
          'title'   => __( 'Menu background color', 'geoport' ),
          'default' => '#ffffff',
          'dependency' => array( 'sticky_menu_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'sticky_menu2_font_color',
          'type'    => 'color_picker',
          'title'   => __( 'Menu font color', 'geoport' ),
          'default' => '#244b5a',
          'dependency' => array( 'sticky_menu_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'sticky_menu2_hover_font_color',
          'type'    => 'color_picker',
          'title'   => __( 'Menu hover font color', 'geoport' ),
          'default' => '#ff5e14',
          'dependency' => array( 'sticky_menu_switch', '==', 'true' ),
        ),

      )
    ),
  
    // Menu 3
    array(
      'name'     => 'menu_3',
      'title'    => 'Menu Style 3',
      'icon'     => 'fal fa-plus',
      'fields'   => array(

        array(
          'type'    => 'subheading',
          'content' => __( 'Menu color', 'geoport' ),
        ),
        array(
          'id'      => 'menu3_bg_color',
          'type'    => 'color_picker',
          'title'   => __( 'Menu background color', 'geoport' ),
          'default' => 'transparent',
        ),
        array(
          'id'      => 'menu3_font_color',
          'type'    => 'color_picker',
          'title'   => __( 'Menu font color', 'geoport' ),
          'default' => '#ffffff',
        ),
        array(
          'id'      => 'menu3_hover_font_color',
          'type'    => 'color_picker',
          'title'   => __( 'Menu hover font color', 'geoport' ),
          'default' => '#34ccff',
        ),

        // Menu 1 Submenu
        array(
          'type'    => 'subheading',
          'content' => __( 'Sub menu color', 'geoport' ),
        ),
        array(
          'id'      => 'submenu3_bg_color',
          'type'    => 'color_picker',
          'title'   => __( 'Background color', 'geoport' ),
          'default' => '#ffffff',
        ),
        array(
          'id'      => 'submenu3_color',
          'type'    => 'color_picker',
          'title'   => __( 'Font color', 'geoport' ),
          'default' => '#244b5a',
        ),
        array(
          'id'      => 'submenu3_hover_color',
          'type'    => 'color_picker',
          'title'   => __( 'Hover font color', 'geoport' ),
          'default' => '#34ccff',
        ),
        array(
          'id'      => 'submenu3_border_color',
          'type'    => 'color_picker',
          'title'   => __( 'Border color', 'geoport' ),
          'default' => '#eceef0',
        ),

        // Language button
        array(
          'type'    => 'subheading',
          'content' => __( 'Language button', 'geoport' ),
        ),
        array(
          'id'      => 'lan3_btn_switch',
          'type'    => 'switcher',
          'title'   =>  __( 'Language button switcher', 'geoport' ),
        ),
        array(
          'id'      => 'lan3_btn_shortcode',
          'type'    => 'textarea',
          'title'   => __( 'language button shortcode', 'geoport' ),
          'desc'   => __( 'Put language button shortcode', 'geoport' ),
          'dependency' => array( 'lan3_btn_switch', '==', 'true' ),
        ),
        
        // Menu button
        array(
          'type'    => 'subheading',
          'content' => __( 'Menu button', 'geoport' ),
        ),
        array(
          'id'      => 'menu3_btn_switch',
          'type'    => 'switcher',
          'title'   =>  __( 'Menu button switcher', 'geoport' ),
          'default' =>  true,
        ),
        array(
          'id'      => 'menu3_btn_icon',
          'type'    => 'icon',
          'title'   => __( 'Button icon', 'geoport' ),
          'default' => 'fal fa-truck',
          'dependency' => array( 'menu3_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu3_btn_text',
          'type'    => 'text',
          'title'   => __( 'Button text', 'geoport' ),
          'default' => 'Track Your Order',
          'dependency' => array( 'menu3_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu3_btn_link',
          'type'    => 'text',
          'title'   => __( 'Button link', 'geoport' ),
          'default' => '#',
          'dependency' => array( 'menu3_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu3_btn_bg_color',
          'type'    => 'color_picker',
          'title'   => __( 'Background color', 'geoport' ),
          'default' => '#34ccff',
          'dependency' => array( 'menu3_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu3_btn_font_color',
          'type'    => 'color_picker',
          'title'   => __( 'Font color', 'geoport' ),
          'default' => '#ffffff',
          'dependency' => array( 'menu3_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu3_btn_border_color',
          'type'    => 'color_picker',
          'title'   => __( 'Border color', 'geoport' ),
          'default' => '#34ccff',
          'dependency' => array( 'menu3_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu3_btn_hf_color',
          'type'    => 'color_picker',
          'title'   => __( 'Hover font color', 'geoport' ),
          'default' => '#ffffff',
          'dependency' => array( 'menu3_btn_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'menu3_btn_hb_color',
          'type'    => 'color_picker',
          'title'   => __( 'Hover background color', 'geoport' ),
          'default' => '#34ccff',
          'dependency' => array( 'menu3_btn_switch', '==', 'true' ),
        ),

        // Sticky menu
        array(
          'type'    => 'subheading',
          'content' => __( 'Sticky menu color', 'geoport' ),
          'dependency' => array( 'sticky_menu_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'sticky_menu3_bg_color',
          'type'    => 'color_picker',
          'title'   => __( 'Menu background color', 'geoport' ),
          'default' => '#ffffff',
          'dependency' => array( 'sticky_menu_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'sticky_menu3_font_color',
          'type'    => 'color_picker',
          'title'   => __( 'Menu font color', 'geoport' ),
          'default' => '#244b5a',
          'dependency' => array( 'sticky_menu_switch', '==', 'true' ),
        ),
        array(
          'id'      => 'sticky_menu3_hover_font_color',
          'type'    => 'color_picker',
          'title'   => __( 'Menu hover font color', 'geoport' ),
          'default' => '#34ccff',
          'dependency' => array( 'sticky_menu_switch', '==', 'true' ),
        ),

      )
    ),

  ),
);



// ===================================================================
// Blog Settings = 
// ===================================================================
$options[]      = array(
  'name'        => 'blog_setting',
  'title'       =>  __( 'Blog Page Settings', 'geoport' ),
  'icon'        => 'fal fa-blog',
   // begin: fields
  'fields'      => array(

    array(
      'type'         => 'heading',
      'content'      =>  __( 'Blog Setting', 'geoport' ),
    ),

    array(
      'id'      => 'blog_page_breadcrumb',
      'type'    => 'text',
      'title'   => __( 'Post details beradcrumb title', 'geoport' ),
      'default' => __( 'Blog Posts', 'geoport' ),
    ),
  
    array(
      'id'           => 'blog_layout',
      'type'         => 'image_select',
      'title'        =>  __( 'Page Layout Style', 'geoport' ),
      'options'      => array(
        'left-sidebar'  => GEOPORT_PLG_URL. 'assets/imgs/sidebar_l.jpg',
        'right-sidebar' => GEOPORT_PLG_URL. 'assets/imgs/sidebar_r.jpg',
        'full-width'    => GEOPORT_PLG_URL. 'assets/imgs/fullwidth.jpg',
        ),
    ),
    array(
      'id'      => 'blog_post_date',
      'type'    => 'switcher',
      'title'   => __( 'Post date meta on?', 'geoport' ),
      'default' => true,
    ),
    array(
      'id'      => 'blog_post_views',
      'type'    => 'switcher',
      'title'   => __( 'Post view meta on?', 'geoport' ),
    ),
    array(
      'id'      => 'blog_post_comments',
      'type'    => 'switcher',
      'title'   => __( 'Post comment meta on?', 'geoport' ),
      'default' => true,
    ),
    array(
      'id'      => 'blog_post_admin',
      'type'    => 'switcher',
      'title'   => __( 'Post meta admin on?', 'geoport' ),
      'default' => true,
    ),
    array(
      'id'      => 'geoport_post_excerpt_length',
      'type'    => 'text',
      'title'   =>  __( 'Blog post content excerpt length', 'geoport' ),
      'default' => '50',
    ),

    array(
      'type'    => 'subheading',
      'content' =>  __( 'Blog Single Page Setting', 'geoport' ),
    ),

    array(
      'id'           => 'blog_single_layout',
      'type'         => 'image_select',
      'title'        =>  __( 'Single Layout Style', 'geoport' ),
      'options'      => array(
        'left-sidebar'  => GEOPORT_PLG_URL. 'assets/imgs/sidebar_l.jpg',
        'right-sidebar' => GEOPORT_PLG_URL. 'assets/imgs/sidebar_r.jpg',
        'full-width'    => GEOPORT_PLG_URL. 'assets/imgs/fullwidth.jpg',
        ),
    ),

    array(
      'id'      => 'blog_single_post_admin',
      'type'    => 'switcher',
      'title'   => __( 'Post meta admin on?', 'geoport' ),
      'default' => true,
    ),
    array(
      'id'      => 'blog_single_post_date',
      'type'    => 'switcher',
      'title'   => __( 'Post meta date on?', 'geoport' ),
      'default' => true,
    ),
    array(
      'id'      => 'blog_single_post_cats',
      'type'    => 'switcher',
      'title'   => __( 'Post categories on?', 'geoport' ),
      'default' => true,
    ),
    array(
      'id'           => 'geoport_post_details_tag_enable',
      'type'         => 'switcher',
      'title'        => __( 'Post details tags On/Off', 'geoport' ),
      'default'      => true,
    ),
    array(
      'id'           => 'geoport_post_details_share_enable',
      'type'         => 'switcher',
      'title'        => __( 'Post details share On/Off', 'geoport' ),
    ),
    array(
      'id'           => 'blog_single_rp_switch',
      'type'         => 'switcher',
      'title'        => __( 'Post details related post On/Off', 'geoport' ),
    ),
    array(
      'id'       => 'rp_grid_columns',
      'type'     => 'select',
      'title'    => __( 'Select Related Post Columns', 'geoport' ),
      'options'  => array(
        '6' => __( '2 Columns', 'geoport' ),
        '4' => __( '3 Columns', 'geoport' ),
        '3' => __( '4 Columns', 'geoport' ),
      ),
      'default'  => '6',
      'dependency'   => array( 'blog_single_rp_switch', '==', 'true' ),
    ),
  
  )
);



// ===================================================================
// Service Settings = 
// ===================================================================
$options[]      = array(
  'name'        => 'service_setting',
  'title'       =>  __( 'Service Page Settings', 'geoport' ),
  'icon'        => 'fal fa-briefcase',
   // begin: fields
  'fields'      => array(

    array(
      'type'    => 'subheading',
      'content' =>  __( 'Service Details Page', 'geoport' ),
    ),

    array(
      'id'           => 'service_details_layout',
      'type'         => 'image_select',
      'title'        =>  __( 'Single Layout Style', 'geoport' ),
      'options'      => array(
        'left-sidebar'  => GEOPORT_PLG_URL. 'assets/imgs/sidebar_l.jpg',
        'right-sidebar' => GEOPORT_PLG_URL. 'assets/imgs/sidebar_r.jpg',
        'full-width'    => GEOPORT_PLG_URL. 'assets/imgs/fullwidth.jpg',
        ),
    ),
    array(
      'id'      => 'service_post_details_thumbnail',
      'type'    => 'switcher',
      'title'   => __( 'Post Thumbnail on?', 'geoport' ),
      'default' => false,
    ),
    array(
      'id'      => 'prev_and_next_post_switch',
      'type'    => 'switcher',
      'title'   => __( 'Pagination switch on?', 'geoport' ),
      'desc'   => __( 'Previous and next post switching', 'geoport' ),
      'default' => true,
    ),
  
  )
);



// ===================================================================
//  Team Settings
// ===================================================================
$options[]      = array(
  'name'        => 'team_setting',
  'title'       => __( 'Team Settings', 'geoport' ),
  'icon'        => 'fal fa-users',
  'fields'      => array(
    
    array(
      'type'    => 'subheading',
      'content' => __( 'Team Single Page Settings', 'geoport' ),
    ),
    array(
      'id'    => 'team_details_breadcrumb_title',
      'type'  => 'text',
      'title' => __( 'Breadcrumb Title', 'geoport' ),
      'default' => __( 'Team Details', 'geoport' ),
    ),
    array(
      'id'    => 'team_post_slug',
      'type'  => 'text',
      'title' => __( 'Post Slug', 'geoport' ),
      'default' => 'team',
    ),
    array(
      'id'           => 'chariton_team_gutenberg',
      'type'         => 'switcher',
      'title'        => __( 'Gutenberg Enable/Disable Switch', 'geoport' ),
      'default'      => true,
    ),
  )
);




// ===================================================================
// 404 Page Settings = 
// ===================================================================

$options[]      = array(
  'name'        => '404_page',
  'title'       =>  __( '404 Page Settings', 'geoport' ),
  'icon'        => 'fal fa-exclamation-triangle',
  // begin: fields
  'fields'      => array(

    array(
      'id'    => '404_breadcrumb_title',
      'type'  => 'text',
      'title' =>  __( 'Breadcrumb title', 'geoport' ),
      'default' => __( '404 Error', 'geoport' ),
    ),
    array(
      'id'    => '404_text',
      'type'  => 'text',
      'title' =>  __( '404 text', 'geoport' ),
      'default' => __( '404', 'geoport' ),
    ),
    array(
      'id'    => '404_page_title',
      'type'  => 'text',
      'title' =>  __( '404 Page Title', 'geoport' ),
      'default' => __( 'Sorry Page Not Found', 'geoport' ),
    ),
    array(
      'id'    => '404_btn_txt',
      'type'  => 'text',
      'title' =>  __( 'Button Text', 'geoport' ),
      'default' => __( ' Go Back Home', 'geoport' ),
    ), 
    array(
      'id'    => '404_btn2_txt',
      'type'  => 'text',
      'title' =>  __( 'Button 2 Text', 'geoport' ),
      'default' => __( 'Subscribe', 'geoport' ),
    ), 
    array(
      'id'    => '404_btn2_link',
      'type'  => 'text',
      'title' =>  __( 'Button 2 Link', 'geoport' ),
      'default' => '#',
    ),
    array(
      'id'         => 'geoport_404_image',
      'type'       => 'image',
      'title'      => __( 'Upload 404 Image', 'geoport' ),
    ),
  
  )
);


// ===================================================================
// Footer Options =
// ===================================================================
$options[]   = array(
  'name'     => 'footer_settings',
  'title'    => __( 'Footer Settings', 'geoport' ),
  'icon'     => 'fab fa-foursquare',
  'sections' => array(

    // Copyright Setting
    array(
      'name'     => 'copyright_settings',
      'title'    => 'Copyright Settings',
      'icon'     => 'fal fa-plus',
      'fields'   => array(
        array(
          'type'    => 'subheading',
          'content' => __( 'Copyright Settings', 'geoport' ),
        ),
        array(
          'id'        => 'copyrights',
          'type'      => 'textarea',
          'title'     =>  __( 'Copyright Text', 'geoport' ),
          'default'   => 'Copyright &copy; 2020, Geoport. Theme Developed by <a href="http://pluginspoint.com/" title="johanspond"> Johanspond</a>',
          'sanitize'  => false,
        ),
        array(
          'id'      => 'footer_copyright_background_color',
          'type'    => 'color_picker',
          'title'   => __( 'Copyright Background Color', 'geoport' ),
          'default' => '#001d67',
        ),
        array(
          'id'      => 'footer_copyright_text_color',
          'type'    => 'color_picker',
          'title'   => __( 'Copyright Text Color', 'geoport' ),
          'default' => '#a7b6d3',
        ),
        array(
          'id'      => 'footer_copyright_link_color',
          'type'    => 'color_picker',
          'title'   => __( 'Copyright Link Color', 'geoport' ),
          'default' => '#ff5e14',
        ),
        array(
          'id'      => 'footer_copyright_linkhv_color',
          'type'    => 'color_picker',
          'title'   => __( 'Copyright Link Hover Color', 'geoport' ),
          'default' => '#ff5e14',
        ),
      )
    ),

    // Footer Widget Columns Setting
    array(
      'name'     => 'footer_widget_columns_settings',
      'title'    => 'Footer Columns',
      'icon'     => 'fal fa-plus',
      'fields'   => array(

        array(
          'type'    => 'subheading',
          'content' => __( 'Footer Columns Settings', 'geoport' ),
        ),
        array(
          'id'             => 'footer_widget1_columns',
          'type'           => 'select',
          'title'          => 'Select Footer 1 Columns',
          'options'        => array(
            '2'   => '2',
            '3'   => '3',
            '4'   => '4',
            '5'   => '5',
            '6'   => '6',
            '7'   => '7',
            '8'   => '8',
          ),
          'default_option' => '5',
          'desc'          => __( 'Total footer area columns is 12', 'geoport' )
        ),
        array(
          'id'             => 'footer_widget2_columns',
          'type'           => 'select',
          'title'          => 'Select Footer 2 Columns',
          'options'        => array(
            '2'   => '2',
            '3'   => '3',
            '4'   => '4',
            '5'   => '5',
            '6'   => '6',
            '7'   => '7',
            '8'   => '8',
          ),
          'default_option' => '3',
          'desc'          => __( 'Total footer area columns is 12', 'geoport' )
        ),
        array(
          'id'             => 'footer_widget3_columns',
          'type'           => 'select',
          'title'          => 'Select Footer 3 Columns',
          'options'        => array(
            '2'   => '2',
            '3'   => '3',
            '4'   => '4',
            '5'   => '5',
            '6'   => '6',
            '7'   => '7',
            '8'   => '8',
          ),
          'default_option' => '4',
          'desc'          => __( 'Total footer area columns is 12', 'geoport' )
        ),
        array(
          'id'             => 'footer_widget4_columns',
          'type'           => 'select',
          'title'          => 'Select Footer 4 Columns',
          'options'        => array(
            '2'   => '2',
            '3'   => '3',
            '4'   => '4',
            '5'   => '5',
            '6'   => '6',
            '7'   => '7',
            '8'   => '8',
          ),
          'default_option' => '3',
          'desc'          => __( 'Total footer area columns is 12', 'geoport' )
        ),

      )
    ),

    // Footer Color
    array(
      'name'     => 'footer_color',
      'title'    => 'Footer Typography',
      'icon'     => 'fal fa-plus',
      'fields'   => array(

        array(
          'type'    => 'subheading',
          'content' => __( 'Footer Widget Settings', 'geoport' ),
        ),
        array(
          'id'      => 'footer_background_color',
          'type'    => 'color_picker',
          'title'   => __( 'Footer background color', 'geoport' ),
          'default' => '#001447',
        ),
        array(
          'id'      => 'ft_fonts_color',
          'type'    => 'color_picker',
          'title'   => __( 'Widget Title Text Color', 'geoport' ),
          'default' => '#ffffff',
        ),
        array(
          'id'      => 'ft_fonts_size',
          'type'    => 'text',
          'title'   => __( 'Widget Title Font Size', 'geoport' ),
          'default' => '24px',
          'info'    => __( 'Put widget title fonts size with px like (34px)', 'geoport' ),
        ),
        array(
          'type'    => 'subheading',
          'content' => __( 'Footer Content Settings', 'geoport' ),
        ),
        array(
          'id'      => 'footer_fonts_color',
          'type'    => 'color_picker',
          'title'   => __( 'Footer Content color', 'geoport' ),
          'default' => '#a7b6d3',
        ),
        array(
          'id'      => 'footer_hover_link_color',
          'type'    => 'color_picker',
          'title'   => __( 'Footer link hover color', 'geoport' ),
        ),

      )
    ),

    // Footer Left Block Setting
    array(
      'name'   => 'footer_left_block_settings',
      'title'  => 'Footer Social',
      'icon'   => 'fal fa-plus',
      'fields' => array(

        array(
          'type'    => 'subheading',
          'content' => __( 'Footer Social Settings', 'geoport' ),
        ),
        array(
          'id'         => 'footer_left_social_font_color',
          'type'       => 'color_picker',
          'title'      =>  __( 'Footer Social fonts color', 'geoport' ),
          'default'    => '#ffffff',
        ),
        array(
          'id'         => 'footer_left_social_bg_color',
          'type'       => 'color_picker',
          'title'      =>  __( 'Footer Social background color', 'geoport' ),
          'default'    => '#1d2b5a',
        ),
        array(
          'id'         => 'footer_left_social_h_font_color',
          'type'       => 'color_picker',
          'title'      =>  __( 'Footer Social hover fonts color', 'geoport' ),
          'default'    => '#ffffff',
        ),
        array(
          'id'         => 'footer_left_social_h_bg_color',
          'type'       => 'color_picker',
          'title'      =>  __( 'Footer Social hover background color', 'geoport' ),
          'default'    => '#34ccff',
        ),

      )
    ),

  ),
);


// ------------------------------
// a seperator                  -
// ------------------------------
$options[] = array(
  'name'   => 'seperator_1',
  'title'  => 'A Seperator',
  'icon'   => 'fa fa-bookmark'
);

// ------------------------------
// backup                       -
// ------------------------------
$options[]   = array(
  'name'     => 'backup_section',
  'title'    => 'Backup',
  'icon'     => 'fa fa-shield',
  'fields'   => array(

    array(
      'type'    => 'notice',
      'class'   => 'warning',
      'content' => 'You can save your current options. Download a Backup and Import.',
    ),

    array(
      'type'    => 'backup',
    ),

  )
);

GEOPORTFramework::instance( $settings, $options );
