( function( $ ) {  
    /**
   * @param $scope The Widget wrapper element as a jQuery element
   * @param $ The jQuery alias
   */ 
   //  var causetimer = function( $scope, $ ) {
   //    // Case Study Carousel
   //    function Cause_Countdown(){
   //        $('[data-countdown]').each(function() {
   //          var $this = $(this), finalDate = $(this).data('countdown');
   //          $this.countdown(finalDate, function(event) {
   //            $this.html(event.strftime('%D Days'));
   //          });
   //        });
   //    }
   //    Cause_Countdown();

   //    // // active
   //    $('.single-services').on('mouseenter', function () {
   //      $(this).addClass('active').parent().siblings().find('.single-services').removeClass('active');
   //    })
      
   //    //end
   // };

  // var causeisotop = function( $scope, $ ) {
  //   // isotop
  //   $('.causes-isotope').imagesLoaded( function() {
  //     // init Isotope
  //     var $grid = $('.causes-isotope').isotope({
  //       itemSelector: '.grid-item',
  //       percentPosition: true,
  //     });
  //     // filter items on button click
  //     $('.causes-menu').on( 'click', 'button', function() {
  //       var filterValue = $(this).attr('data-filter');
  //       $grid.isotope({ filter: filterValue });
  //     });
  //   });
  // }
  // var eventisotop = function( $scope, $ ) {
  //   // isotop
  //   $('.event-active').imagesLoaded( function() {
  //     // init Isotope
  //     var $grid = $('.event-active').isotope({
  //       itemSelector: '.grid-item',
  //       percentPosition: true,
  //     });
  //     // filter items on button click
  //     $('.events-menu').on( 'click', 'button', function() {
  //       var filterValue = $(this).attr('data-filter');
  //       $grid.isotope({ filter: filterValue });
  //     });
  //   });
  // }

  // counterUp
  var counterpreset = function( $scope, $ ) {
    $('.count').counterUp({
      delay: 10,
      time: 2000
    });
  }

  var databg_img = function( $scope, $ ) {
    // data - background
    $("[data-background]").each(function () {
      $(this).css("background-image", "url(" + $(this).attr("data-background") + ")")
    })
  }
  
  // Make sure you run this code under Elementor.
  $( window ).on( 'elementor/frontend/init', function() {
    // elementorFrontend.hooks.addAction( 'frontend/element_ready/section-cause.default', causetimer );
    // elementorFrontend.hooks.addAction( 'frontend/element_ready/image-box-item.default', causetimer );
    // elementorFrontend.hooks.addAction( 'frontend/element_ready/section-cause.default', causeisotop );
    // elementorFrontend.hooks.addAction( 'frontend/element_ready/section-event.default', eventisotop );
    elementorFrontend.hooks.addAction( 'frontend/element_ready/counter-items.default', counterpreset );
    elementorFrontend.hooks.addAction( 'frontend/element_ready/contact-tab.default', databg_img );
  } );
})( jQuery );